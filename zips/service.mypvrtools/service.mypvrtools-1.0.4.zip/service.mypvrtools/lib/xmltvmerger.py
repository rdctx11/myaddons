import threading
import requests
import shutil
import os
import time
import gzip
import datetime
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import sys
from common_variables import *

def xml_merge(notification=False):
		
	if selfAddon.getSetting('xmltv1') == 'true':
		if selfAddon.getSetting('xmltv1-type') == '1':
			t1 = threading.Thread(name='xml1', target=download_and_extract , args=(selfAddon.getSetting('xmltv1-url'),))
		else:
			t1 = threading.Thread(name='xml1', target=copy_file , args=(selfAddon.getSetting('xmltv1-loc'),))	
		t1.start()
		
	if selfAddon.getSetting('xmltv2') == 'true':
		if selfAddon.getSetting('xmltv2-type') == '1':
			t2 = threading.Thread(name='xml2', target=download_and_extract , args=(selfAddon.getSetting('xmltv2-url'),))
		else:
			t2 = threading.Thread(name='xml2', target=copy_file , args=(selfAddon.getSetting('xmltv2-loc'),))	
		t2.start()
		
	if selfAddon.getSetting('xmltv3') == 'true':
		if selfAddon.getSetting('xmltv3-type') == '1':
			t3 = threading.Thread(name='xml3', target=download_and_extract , args=(selfAddon.getSetting('xmltv3-url'),))
		else:
			t3 = threading.Thread(name='xml3', target=copy_file , args=(selfAddon.getSetting('xmltv3-loc'),))	
		t3.start()
		
	if selfAddon.getSetting('xmltv4') == 'true':
		if selfAddon.getSetting('xmltv4-type') == '1':
			t4 = threading.Thread(name='xml4', target=download_and_extract , args=(selfAddon.getSetting('xmltv4-url'),))
		else:
			t4 = threading.Thread(name='xml4', target=copy_file , args=(selfAddon.getSetting('xmltv4-loc'),))	
		t4.start()
		
	if selfAddon.getSetting('xmltv5') == 'true':
		if selfAddon.getSetting('xmltv5-type') == '1':
			t5 = threading.Thread(name='xml5', target=download_and_extract , args=(selfAddon.getSetting('xmltv5-url'),))
		else:
			t5 = threading.Thread(name='xml5', target=copy_file , args=(selfAddon.getSetting('xmltv5-loc'),))	
		t5.start()
		
	if selfAddon.getSetting('xmltv6') == 'true':
		if selfAddon.getSetting('xmltv6-type') == '1':
			t6 = threading.Thread(name='xml6', target=download_and_extract , args=(selfAddon.getSetting('xmltv6-url'),))
		else:
			t6 = threading.Thread(name='xml6', target=copy_file , args=(selfAddon.getSetting('xmltv6-loc'),))	
		t6.start()
		
	if selfAddon.getSetting('xmltv7') == 'true':
		if selfAddon.getSetting('xmltv7-type') == '1':
			t7 = threading.Thread(name='xml7', target=download_and_extract , args=(selfAddon.getSetting('xmltv7-url'),))
		else:
			t7 = threading.Thread(name='xml7', target=copy_file , args=(selfAddon.getSetting('xmltv7-loc'),))	
		t7.start()
		
	if selfAddon.getSetting('xmltv8') == 'true':
		if selfAddon.getSetting('xmltv8-type') == '1':
			t8 = threading.Thread(name='xml8', target=download_and_extract , args=(selfAddon.getSetting('xmltv8-url'),))
		else:
			t8 = threading.Thread(name='xml8', target=copy_file , args=(selfAddon.getSetting('xmltv8-loc'),))	
		t8.start()
		
	if selfAddon.getSetting('xmltv9') == 'true':
		if selfAddon.getSetting('xmltv9-type') == '1':
			t9 = threading.Thread(name='xml9', target=download_and_extract , args=(selfAddon.getSetting('xmltv9-url'),))
		else:
			t9 = threading.Thread(name='xml9', target=copy_file , args=(selfAddon.getSetting('xmltv9-loc'),))	
		t9.start()
		
	if selfAddon.getSetting('xmltv10') == 'true':
		if selfAddon.getSetting('xmltv10-type') == '1':
			t10 = threading.Thread(name='xml10', target=download_and_extract , args=(selfAddon.getSetting('xmltv10-url'),))
		else:
			t10 = threading.Thread(name='xml10', target=copy_file , args=(selfAddon.getSetting('xmltv10-loc'),))	
		t10.start()
						
	try:t1.join()
	except:pass
	try: t2.join()
	except:pass
	try: t3.join()
	except:pass
	try: t4.join()
	except:pass
	try: t5.join()
	except:pass
	try: t6.join()
	except:pass
	try: t7.join()
	except:pass
	try: t8.join()
	except:pass
	try: t9.join()
	except:pass
	try: t10.join()
	except:pass
	
	print "Starting extraction process..."
	
	dirs, files = xbmcvfs.listdir(os.path.join(datapath,'download_folder'))
	for xml_name in files:
		if xml_name.endswith('.gz'):
			# inF = gzip.GzipFile(os.path.join(datapath,'download_folder',xml_name), 'rb')
			inF = file(os.path.join(datapath,'download_folder',xml_name), 'rb')
			s = inF.read()
			inF.close()
			outF = file(os.path.join(datapath,'download_folder',xml_name.replace('.gz','.xml')),'wb')
			outF.write(s)
			outF.close()
			os.remove(os.path.join(datapath,datapath,'download_folder',xml_name))
		else:
			print xml_name + " It's not a zip ... skip"
	print "Extracting done"
	print "merging starts here...."
	dirs, xmltv_list = xbmcvfs.listdir(os.path.join(datapath,'download_folder'))
	out = os.path.join(selfAddon.getSetting('output_folder'),selfAddon.getSetting('file_name').replace('.xml','')+'.xml')
	if xbmcvfs.exists(out): os.remove(out)
	i=1
	total = len(xmltv_list)
	for xmltv in xmltv_list:
		if xmltv.endswith('.xml'):
			if i==1:
				f = open(os.path.join(datapath,'download_folder',xmltv), "r")
				text = f.read()
				f.close()
				with open(out, "a") as myfile:
					myfile.write(text.replace('</tv>',''))
			elif i==total:
				o = open(out,"a")
				f = open(os.path.join(datapath,'download_folder',xmltv),"r")
				lines = f.readlines()
				f.close()
				li = 0
				for line in lines:
					if li == 0 or li == 1: pass
					else: o.write(line)
					li += 1
				o.close()
			else:
				o = open(out,"a")
				f = open(os.path.join(datapath,'download_folder',xmltv),"r")
				lines = f.readlines()
				total_lines = len(lines)
				f.close()
				li = 0
				for line in lines:
					if li == 0 or li == 1: pass
					elif li == (total_lines -1): pass
					else: o.write(line)
					li += 1
				o.close()
			os.remove(os.path.join(datapath,'download_folder',xmltv))
			i += 1
	print "Xmltvs have been merged"
	if notification:
		xbmc.executebuiltin("Notification(%s,%s,%i,%s)" % ('My PVR Tools', "EPG's Merged!", 1,os.path.join(addonfolder,"icon.png")))
	return
