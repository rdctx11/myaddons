# -*- coding: utf-8 -*-


import urllib,urllib2,re, xbmcplugin, xbmcgui, xbmc, xbmcaddon
import urlresolver
import cookielib
from addon.common.addon import Addon
from addon.common.net import Net

net = Net(http_debug=True)
ADDON = xbmcaddon.Addon(id='plugin.video.myplayer')
FanArt = ADDON.getAddonInfo('fanart')
addon_id = 'plugin.video.myplayer'
addon = Addon(addon_id, sys.argv)
selfAddon = xbmcaddon.Addon(id=addon_id)
mode = addon.queries['mode']
url = addon.queries.get('url', '')
name = addon.queries.get('name', '')
thumb = addon.queries.get('thumb', '')
iconimage = addon.queries.get('iconimage', '')

eIcon = xbmc.translatePath('special://home/addons/plugin.video.myplayer/resources/art/error.png')



def MainDir():    
    addDir('There are no items here!','https://www.dropbox.com/s/t2zpcggie81fhve/PinoyTV2.xml?dl=1',1,eIcon,FanArt)
	

def OpenUrl(url):
	req=urllib2.Request(url)
	req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response=urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link		
		
		
def GetItems(mname,murl):
	link=OpenUrl(murl)
	link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
	f=re.findall('<fanart>(.+?)</fanart>',link)
	if f:
			fanart=f[0]
	else:
			fanart=''
	match=re.compile('<title>([^<]+)</title.+?link>(.+?)</link.+?thumbnail>([^<]+)</thumbnail>').findall(link)		
	for name,url,thumb in match:
		addLink(name,url,'2',thumb,fanart)
		
def PlayLive(murl):
	ok=True
	playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	playlist.clear()
	stream_url = murl
	listitem = xbmcgui.ListItem(path=stream_url)
	listitem.setPath(stream_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	
	return ok
			
def PlayItems(mname,murl,thumb):
	ok=True
	namelist=[]
	urllist=[]
	playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	playlist.clear()
	if '</regex>'in murl: 
			murl=doRegex(murl)
	match=re.compile('<sublink>(.+?)</sublink>').findall(murl)
	if match:
			i=1
			for url in match:
					name= '[B]'+mname +'[/B]' + '[COLOR yellow]   Link '+ str(i) +'[/COLOR]'
					namelist.append(name)        
					urllist.append(url)
					i=i+1
			dialog = xbmcgui.Dialog()
			answer =dialog.select("Choose A Link :", namelist)
			if answer != -1:
					murl=urllist[int(answer)]
			else:
				  return
	
	stream_url = murl
	urls = murl    
	hmf = urlresolver.HostedMediaFile(urls)
	if hmf:
		 xbmc.executebuiltin("XBMC.Notification(Please wait!,Opening Link,2000)")
		 host = hmf.get_host()
		 dlurl = urlresolver.resolve(urls)
		 ResolveItems(mname,dlurl,'')

	else:
		 xbmc.sleep(1000)
		 ResolveItems(mname,murl,'')
	return ok


def ResolveItems(name,url,thumb):
	 params = {'url':url, 'name':name, 'thumb':thumb}
	 addon.add_video_item(params, {'title':name}, img=thumb)
	 liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumb)
	 xbmc.Player ().play(str(url), liz, False)
	 return
		 
		 
def doRegex(murl):
    #rname=rname.replace('><','').replace('>','').replace('<','')
    import urllib2
    url=re.compile('([^<]+)<regex>',re.DOTALL).findall(murl)[0]
    doRegexs = re.compile('\$doregex\[([^\]]*)\]').findall(url)
    for k in doRegexs:
        if k in murl:
            regex=re.compile('<name>'+k+'</name><expres>(.+?)</expres><page>(.+?)</page><referer>(.+?)</referer></regex>',re.DOTALL).search(murl)
            referer=regex.group(3)
            if referer=='':
                referer=regex.group(2)
            req = urllib2.Request(regex.group(2))
            req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:10.0a1) Gecko/20111029 Firefox/10.0a1')
            req.add_header('Referer',referer)
            response = urllib2.urlopen(req)
            link=response.read()
            response.close()
            link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\/','/')
            r=re.compile(regex.group(1),re.DOTALL).findall(link)[0]
            url = url.replace("$doregex[" + k + "]", r)
   
    return url
		
		
def addLink(name,url,mode,thumb,fanart):
        fanart = fanart
        params = {'url':url, 'mode':mode, 'name':name, 'thumb':thumb, 'fanart':fanart}        
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumb)
        liz.setInfo( type="Video", infoLabels={ "title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
		
		
def addDir(name,url,mode,thumb,fanart):
        fanart = fanart
        params = {'url':url, 'mode':mode, 'name':name, 'thumb':thumb, 'fanart':fanart}        
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumb)
        liz.setInfo( type="Video", infoLabels={ "title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
		
def AUTO_VIEW(content):
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
                if ADDON.getSetting('auto-view') == 'true':        
                   xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting('default-view') )
		
		

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param
              
params=get_params()



try: name=urllib.unquote_plus(params["name"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: mode=int(params["mode"])
except: pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
    iconimage = iconimage.replace(' ','%20')
except: pass
try: plot=urllib.unquote_plus(params["plot"])
except: pass
try:
    fanart=urllib.unquote_plus(params["fanart"])
    fanart = fanart.replace(' ','%20')
except: pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Thumb: "+str(iconimage)


if mode==None or url==None or len(url)<1:
        print ""
        MainDir()

elif mode==1:
    print ""
    GetItems(name,url)

elif mode==2:
    PlayItems(name,url,iconimage)

elif mode==3:
    PlayLive(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))        
