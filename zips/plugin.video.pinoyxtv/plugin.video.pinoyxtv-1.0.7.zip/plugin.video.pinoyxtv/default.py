import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, xbmcaddon
import urlresolver
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.pinoyxtv'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'pinoyxtv'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"
BASEURL1 = 'https://mangpopoy.info'
BASEURL2 = 'https://pinoymoviestreaming.com/category/x-rated/'
BASEURL3 = 'https://javdude.com'
BASEURL4 = 'https://seriestop.co/show/naked-news'

def Start():
	kb =xbmc.Keyboard ('', 'heading', True)
	kb.setHeading('Enter Password') # optional
	kb.setHiddenInput(True) # optional
	kb.doModal()
	if (kb.isConfirmed()):
		text = kb.getText()
		if addon.get_setting('password')==text:
			MENU()
		else:
			dialog = xbmcgui.Dialog()
			ok = dialog.ok('Attention!', ' \n                          You entered a wrong password.\n                                       Please Try Again!')
			return exit()

def MENU():
	addDir('Mangpopoy Videos','url',2,ART + 'mangpopoyvids.png',ART + 'fanart2.jpg','')
	addDir('X-Rated Movies',BASEURL2,30,ART + 'xmovies.png',FANART,'')
	addDir('JAV XXX','url',40,ART + 'jav.png',ART + 'fanart3.jpg','')
	addDir('NAVI X Adult Videos','url',45,ART + 'navixxx.png',ART + 'fanart5.jpg','')
	addDir('Adult IPTV','http://playlist.autoiptv.net/adult.php',55,ART + 'adultch.png',ART + 'fanart6.jpg','')
	# addDir('Naked News','url',50,ART + 'nakednews.png',ART + 'fanart4.jpg','')
	setView('addons', 'cat-view')

def mangpopoy_videos():
    addDir('Latest Videos',BASEURL1,20,ART + 'latestvids.png',ART + 'fanart2.jpg','') 
    addDir('Pinay',BASEURL1+'/category/pinay/',20,ART + 'pinay.png',ART + 'fanart2.jpg','') 
    addDir('Asian',BASEURL1+'/category/asian/',20,ART + 'asian.png',ART + 'fanart2.jpg','') 
    addDir('Indonesian Porn',BASEURL1+'/category/indonesian-porn/',20,ART + 'indoporn.png',ART + 'fanart2.jpg','') 
    addDir('Malaysian Sex',BASEURL1+'/category/malaysian-sex/',20,ART + 'malaysex.png',ART + 'fanart2.jpg','') 
    addDir('Western Sex',BASEURL1+'/category/western-sex/',20,ART + 'westsex.png',ART + 'fanart2.jpg','')  
    addDir('Pinay Scandal',BASEURL1+'/category/pinay-scandal/',20,ART + 'pinayscandal.png',ART + 'fanart2.jpg','')
    addDir('Search','url',22,ART + 'search.png',ART + 'fanart2.jpg','')
    setView('addons', 'cat-view')
    
def mangpopoy_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<article id=.+?href="(.+?)".+?<img data-src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        addDir('%s' %name,url,99,icon,ART + 'fanart2.jpg','')
    pages = re.compile("<li><a href='(.+?)'(.+?)</a></li>",re.DOTALL).findall(OPEN)
    for url,name in pages:
		name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('>','').replace(' class="inactive"','Page ')
		addDir('[COLOR red]%s[/COLOR]' %name,url,20,ART + 'page.png',ART + 'fanart2.jpg','')
    np = re.compile('rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[COLOR red]Next[/COLOR]',url,20,ART + 'page.png',ART + 'fanart2.jpg','')
	setView('episodes', 'video-view')
    
def mangpopoy_links(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<source src="(.+?)" type="video/mp4"',re.DOTALL).findall(OPEN)
    for url in Regex:
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('%s' %name2,url,99,iconimage,ART + 'fanart2.jpg',name)
    altlinks = re.compile('class="responsive-player".+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in altlinks:
        url = url.replace('https://href.li/?','')
        if 'dailymotion' in altlinks:
            url = 'http:' + url
        if urlresolver.HostedMediaFile(url).valid_url():    
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('%s' %name2,url,99,iconimage,ART + 'fanart2.jpg',name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def mangpopoy_Search():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ','+')
            url = BASEURL1 + '/?s=' + search
            mangpopoy_content(url)
    
def xmovies_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('tag-x-rated">.+?<a class="clip-link".+?href="(.+?)".+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        addDir('%s' %name,url,99,icon,FANART,'')
    pages = re.compile('<a class="page.+?title="(.+?)" href="(.+?)"',re.DOTALL).findall(OPEN)
    for name,url in pages:
        addDir('[COLOR red]%s[/COLOR]' %name,url,30,ART + 'page.png',FANART,'')
	setView('movies', 'movie-view')
    
def xmovies_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<source src="(.+?)" type="video/mp4"',re.DOTALL).findall(OPEN)
    for url in Regex:
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,99,iconimage,FANART,name)
    altlinks = re.compile('src="(.+?)"',re.DOTALL).findall(OPEN)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def jav_videos():
    addDir('JAV XXX',BASEURL3,41,ART + 'jav.png',ART + 'fanart3.jpg','')
    # addDir('JAV Uncen',BASEURL3+ '/tag/uncensor/',41,ART + 'jav.png',ART + 'fanart3.jpg','')
    addDir('Europe',BASEURL3+ '/category/europe-porn/',41,ART + 'jav.png',ART + 'fanart3.jpg','')
    addDir('SEARCH',url,43,ART + 'jav.png',ART + 'fanart3.jpg','')
    setView('addons', 'cat-view')
    
def jav_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="entry">.+?href="(.+?)" title="(.+?)".+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        addDir('%s' %name,url,42,icon,icon,'')
    pages = re.compile("<div class='wp-pagenavi'>(.+?)</div></div>",re.DOTALL).findall(OPEN)
    pages2 = re.compile('<a class=.+?href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(pages))
    for url,name in pages2:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&laquo;','<<<').replace('&raquo;','>>>')
        addDir('[B][COLOR red]%s[/COLOR][/B]' %name,url,41,ART + 'page.png',ART + 'fanart3.jpg','')
    setView('episodes', 'video-view')
    
def jav_links(name,url):
    OPEN = Open_Url(url)
    links = re.compile('<span id="more-(.+?)<div class="crp_clear">',re.DOTALL).findall(OPEN)
    links2 = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(str(links))
    for url in links2:
        if 'thplayers.com' in url:
            url = 'https:' + url    
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('%s' %name2,url,99,iconimage,iconimage,name)
        if urlresolver.HostedMediaFile(url).valid_url():    
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('%s' %name2,url,99,iconimage,iconimage,name)
	setView('files', '50')

def jav_Search():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ','+')
            url = BASEURL3 + '/?s=' + search
            jav_content(url)
			

def navixxx_videos():
    addDir('Adult Movies 1','https://pastebin.com/raw/Lj3MXfzb',47,ART + 'navixxx.png',ART + 'fanart5.jpg','')
    addDir('Adult Movies 2','https://pastebin.com/raw/gAaCB30C',47,ART + 'navixxx.png',ART + 'fanart5.jpg','')
    addDir('Classic Adult Movies 1','https://pastebin.com/raw/xLTsd2i6',47,ART + 'navixxx.png',ART + 'fanart5.jpg','')
    addDir('Classic Adult Movies 2','https://pastebin.com/raw/texDKX7z',47,ART + 'navixxx.png',ART + 'fanart5.jpg','')
    addDir('Classic Adult Movies 3','https://pastebin.com/raw/pcvpXSUM',47,ART + 'navixxx.png',ART + 'fanart5.jpg','')
    addDir('JAV 18+ Uncensored','https://pastebin.com/raw/7KSsBuNE',46,ART + 'navixxx.png',ART + 'fanart5.jpg','')
    addDir('JAV 18+ Collection 1','https://pastebin.com/raw/H5td0ZrZ',46,ART + 'navixxx.png',ART + 'fanart5.jpg','')
    addDir('JAV 18+ Collection 2','https://pastebin.com/raw/GkWbAB7Q',46,ART + 'navixxx.png',ART + 'fanart5.jpg','')
    addDir('JAV 18+ Collection 3','https://pastebin.com/raw/sqsmPceq',47,ART + 'navixxx.png',ART + 'fanart5.jpg','')
    addDir('Asian Sex Diary','https://pastebin.com/raw/kGZL6LUh',47,ART + 'navixxx.png',ART + 'fanart5.jpg','')
    setView('addons', 'cat-view')
    
def navixxx_content(url):
    Link = Open_Url(url)
    Link=Link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('type=playlistname=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('type=playlistname=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('name=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('name=Sorted by user-assigned order','')
    Regex = re.compile('type=videoname=(.+?)thumb=(.+?)URL=(.+?)player=').findall(Link)
    for name,icon,url in Regex:
        addDir('%s' %name,url,99,icon,icon,'')
	setView('episodes', '')
    
def navixxx_content2(url):
    Link = Open_Url(url)
    Link=Link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('type=playlistname=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('type=playlistname=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('name=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('name=Sorted by user-assigned order','')
    Regex = re.compile('type=videoname=(.+?)thumb=(.+?)URL=(.+?)player=').findall(Link)
    for name,icon,url in Regex:
        addDir('%s' %name,url,99,icon,icon,'')
	setView('movies', '')
		

def adultiptv_content(url):
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        response=link
        response = response.replace('#AAASTREAM:','#A:')
        response = response.replace('#EXTINF:','#A:')
        matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
        li = []
        for params, display_name, url in matches:
            item_data = {"params": params, "display_name": display_name, "url": url}
            li.append(item_data)
        list = []
        for channel in li:
            item_data = {"display_name": channel["display_name"], "url": channel["url"]}
            matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
            for field, value in matches:
                item_data[field.strip().lower().replace('-', '_')] = value.strip()
            list.append(item_data)
        for channel in list:
            name = GetEncodeString(channel["display_name"])
            url = GetEncodeString(channel["url"])
            if addon.get_setting('M3U8_Mode') == "true":
				url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8').replace('.ts','.m3u8')
            else:
				url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
            addDir(name,url,56,ART + 'adultch.png',ART + 'fanart6.jpg','')
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR yellow]Server is down. Please try again later.[/COLOR] ,5000)")
        quit()

    xbmcplugin.setContent(int(sys.argv[1]), 'files')

def iptv_player(name,url,iconimage):
    try:
        name,url = url.split('|SPLIT|')
    except: pass
    if not 'f4m'in url:
        if '.m3u8'in url:
            url = 'plugin://plugin.video.f4mTester/?url='+url+'&amp;streamtype=HLSRETRY&amp;name='+name+'&amp;iconImage='+iconimage
        elif '.ts'in url:
            url = 'plugin://plugin.video.f4mTester/?url='+url+'&amp;streamtype=TSDOWNLOADER&amp;name='+name+'&amp;iconImage='+iconimage
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    xbmc.Player().play(url,liz,False)

def nakednews_videos():
    addDir('All Seasons','https://seriestop.co/show/naked-news',51,ART + 'nakednews.png',ART + 'fanart4.jpg','')
    addDir('Season 2018','https://seriestop.co/show/naked-news/season/2018',51,ART + 'nakednews.png',ART + 'fanart4.jpg','')
    addDir('Season 2017','https://seriestop.co/show/naked-news/season/2017',51,ART + 'nakednews.png',ART + 'fanart4.jpg','')
    setView('addons', 'cat-view')
    
def nakednews_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<a title=.+?href="(.+?)".+?src=(.+?)&amp.+?<span title="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon,name in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('Naked News Magazine','')
        addDir('Naked News %s' %name,url,52,icon,ART + 'fanart4.jpg','')
    setView('episodes', 'video-view')
    
def nakednews_links(name,url):
    OPEN = Open_Url(url)
    links = re.compile('<span id="more-(.+?)<div class="crp_clear">',re.DOTALL).findall(OPEN)
    links2 = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(str(links))
    for url in links2:
        if 'thplayers.com' in url:
            url = 'https:' + url    
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('%s' %name2,url,99,iconimage,iconimage,name)
        if urlresolver.HostedMediaFile(url).valid_url():    
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('%s' %name2,url,99,iconimage,iconimage,name)
	setView('files', '50')
 
def RESOLVE(url):
   
    try:
        if 'mangpopoy.info' in url:
			OPEN = Open_Url(url)
			url = re.compile('<div class="responsive-player".+?src="(.+?)"',re.DOTALL).findall(OPEN)[0]
			url = url.replace('https://href.li/?','')
			if 'mangpopoy.info' in url:
				stream_url = url
			else:
				stream_url = urlresolver.resolve(url)
        elif 'pinoymoviestreaming.com' in url:
			OPEN = Open_Url(url)
			url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
			stream_url = urlresolver.resolve(url)
        elif 'thplayers.com' in url:
			OPEN = Open_Url(url)
			url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
			stream_url = urlresolver.resolve(url)
        else:
            stream_url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR yellow]Link is not working![/COLOR] ,3000)")

def GetEncodeString(str):
    try:
        import chardet
        str = str.decode(chardet.detect(str)["encoding"]).encode("utf-8")
    except:
        try:
            str = str.encode("utf-8")
        except:
            pass
    return str 

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link
    
def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==99 or mode==56:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
    
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass

if mode==None or url==None or len(url)<1 : Start()

elif mode == 2 : mangpopoy_videos()
elif mode == 20 : mangpopoy_content(url)
elif mode == 21 : mangpopoy_links(url)
elif mode == 22 : mangpopoy_Search()
elif mode == 30 : xmovies_content(url)
elif mode == 31 : xmovies_links(name,url)
elif mode == 40 : jav_videos()
elif mode == 41 : jav_content(url)
elif mode == 42 : jav_links(name,url)
elif mode == 43 : jav_Search()
elif mode == 45 : navixxx_videos()
elif mode == 46 : navixxx_content(url)
elif mode == 47 : navixxx_content2(url)
elif mode == 50 : nakednews_videos()
elif mode == 51 : nakednews_content(url)
elif mode == 52 : nakednews_links(name,url)
elif mode == 55 : adultiptv_content(url)
elif mode == 56 : iptv_player(name,url,iconimage)
elif mode == 99	: RESOLVE(url)




xbmcplugin.endOfDirectory(int(sys.argv[1]))