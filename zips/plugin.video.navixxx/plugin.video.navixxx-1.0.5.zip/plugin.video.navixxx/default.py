# -*- coding: utf-8 -*-


import urllib,urllib2,re, xbmcplugin, xbmcgui, xbmc, xbmcaddon
import urlresolver
import cookielib
from addon.common.addon import Addon
from addon.common.net import Net

net = Net(http_debug=True)
ADDON = xbmcaddon.Addon(id='plugin.video.navixxx')
FanArt = ADDON.getAddonInfo('fanart')
addon_id = 'plugin.video.navixxx'
addon = Addon(addon_id, sys.argv)
selfAddon = xbmcaddon.Addon(id=addon_id)
mode = addon.queries['mode']
url = addon.queries.get('url', '')
name = addon.queries.get('name', '')
thumb = addon.queries.get('thumb', '')
iconimage = addon.queries.get('iconimage', '')
description = addon.queries.get('description', '')

eIcon = xbmc.translatePath('special://home/addons/plugin.video.navixxx/resources/art/error.png')



def MainDir():    
    # addDir('Pinoy TV Live','file:///D:/Downloads/XBMC/XML/PinoyTV.xml',1,xbmc.translatePath('special://home/addons/plugin.video.navixxx/resources/art/navixxx.jpg'),FanArt,'')
    # addDir('Adult Channels','https://dl.dropboxusercontent.com/u/62302783/Navix%20Playlists/AdultTV.xml',1,'http://funk.co.uk/blogpix/adult_18.gif','http://i1297.photobucket.com/albums/ag26/nieldc/Adult/AdultChannel_zpshza3sipo.jpg','')
    # addDir('Naked News','https://dl.dropboxusercontent.com/u/62302783/Navix%20Playlists/NakedNews.xml',1,'https://dl.dropboxusercontent.com/u/62302783/PVR/logos/nakednews.png','http://ist2-2.filesor.com/pimpandhost.com/5/9/1/7/59170/1/I/S/v/1ISvz/naked-news-anchors6.jpg','')
    # addDir('Porn Collection','https://dl.dropboxusercontent.com/u/62302783/Navix%20Playlists/PornCollection.xml',3,'http://i.imgur.com/W6K7S4E.jpg','http://i.imgur.com/N3LgvWa.jpg','')
    addDir('VideoBronx','http://www.navixtreme.com/playlist/148106/videobronx.plx',3,'http://i.imgur.com/Bxl5aNF.png',FanArt,'')
    addDir('96_2_69_OHOHD_9_18+_XXX','http://www.navixtreme.com/playlist/161767/96_2_69_ohohd_9_18_xxx.plx',6,xbmc.translatePath('special://home/addons/plugin.video.navixxx/resources/art/navixxx.png'),FanArt,'')
    addDir('JAV_16_18+_UNCEN','http://www.navixtreme.com/playlist/161930/jav_16_18_uncen.plx',6,'https://1.bp.blogspot.com/-bmOEHJnOIeQ/WN3Lr_siaTI/AAAAAAAAK3Y/6Cntr1c9E8s-vEBYTfF0Up7bLoV4eKGTACLcB/s1600/Screenshot_4.png',FanArt,'')
    addDir('JAV_15_18+_PIES','http://www.navixtreme.com/playlist/161802/jav_15_18_pies.plx',6,'https://1.bp.blogspot.com/-0SHliKXa8IE/WNXRXV6CFmI/AAAAAAAAKsY/Wi7ZUmlK7kkkDJaqepBssGcCnrmUqmDAQCLcB/s1600/Screenshot_2.png',FanArt,'')
    addDir('JAV_14_18+','http://www.navixtreme.com/playlist/161752/jav_14_18.plx',6,'https://3.bp.blogspot.com/-zGrXN5iQJe4/WKQO_FM3yrI/AAAAAAAAJyI/PNf95ISPlJYONuSs1yEtt4hTvcESHO0QQCLcB/s1600/Screenshot_5.png',FanArt,'')
    addDir('JAV_13_18+','http://www.navixtreme.com/playlist/161588/jav_13_18.plx',6,'https://4.bp.blogspot.com/-NAc5qntvJ9w/WDooK8IhlZI/AAAAAAAAIG8/40KjUCJIfeI_hy8-6qXiT3sQ3MYAflYGQCLcB/s1600/Screenshot_5.jpg',FanArt,'')
    addDir('JAV_12_18+_PIES','http://www.navixtreme.com/playlist/161584/jav_12_18_pies.plx',6,'https://2.bp.blogspot.com/-T7UsMMmw83Q/WAjTF9x6sSI/AAAAAAAAADE/_Y7hME-cg8oNPf1ViTGxDKb3svxpZSUigCLcB/118abp484pl.jpg',FanArt,'')
    addDir('JAV_11_18+','http://www.navixtreme.com/playlist/161583/jav_11_18.plx',6,'https://2.bp.blogspot.com/-tMwcT_vhg6k/WIHEFLXJu0I/AAAAAAAAJQ8/ZtQIt1k2y7EOqjw61blGwOH5eixmnEj2QCLcB/s1600/16195452_1624067527620012_6104218696218545770_n.jpg',FanArt,'')
    addDir('JAV_10_18+_PIES','http://www.navixtreme.com/playlist/161508/jav_10_18_pies.plx',6,'https://2.bp.blogspot.com/-3f6t02rRhwU/WENrPXzn1WI/AAAAAAAAIRM/Sm-evfPoXJwCvf2J-FAWvGoFZl_F4m89QCLcB/s1600/Screenshot_4.jpg',FanArt,'')
    addDir('JAV_9_18+','http://www.navixtreme.com/playlist/161399/jav_9_18.plx',6,'https://2.bp.blogspot.com/-6jeRMgUsKxg/WD4XMW8ydVI/AAAAAAAAIL4/zPdaWRp2YegsqH1SxI7Ba70tw_fCZ4c0QCLcB/s1600/Screenshot_3.jpg',FanArt,'')
    addDir('JAV_8_18+','http://www.navixtreme.com/playlist/161168/jav_8_18.plx',6,'https://4.bp.blogspot.com/-C7csTF1q8nY/Vt4kTETudAI/AAAAAAAA1Dw/0M_MOxwW2TQ/s320/13.jpg',FanArt,'')
    addDir('JAV_7_18+','http://www.navixtreme.com/playlist/161126/jav_7_18.plx',6,'http://2.bp.blogspot.com/-tABTccAk_d4/VrFch-8PnUI/AAAAAAAAy_A/Q01vrh77mqg/s320/142.jpg',FanArt,'')
    addDir('JAV_6_18+','http://www.navixtreme.com/playlist/161100/jav_6_18.plx',6,'https://4.bp.blogspot.com/-TcZT9b5svFc/Vrvglz2oDwI/AAAAAAAAzaA/LewJ4aDgN3I/s320/66.jpg',FanArt,'')
    addDir('JAV_5_18+','http://www.navixtreme.com/playlist/160999/jav_5_18.plx',6,'https://1.bp.blogspot.com/--tN411G5Kc0/VyK-D2SLCoI/AAAAAAAA4JE/dr9NBTp159Ms2B-CGFSSWzt14bXkt8YjgCLcB/s320/18.jpg',FanArt,'')
    addDir('JAV_4_18+','http://www.navixtreme.com/playlist/160834/jav_4_18.plx',6,'http://2.bp.blogspot.com/-DRLGd1y5gg4/VoSrrkhKChI/AAAAAAAAw18/jemyyXO7pNM/s1600/1603.jpg',FanArt,'')
    addDir('JAV_3_18+','http://www.navixtreme.com/playlist/159903/jav_3_18.plx',6,'https://2.bp.blogspot.com/-qZHRrRUyHAU/WHgemC6PBEI/AAAAAAAAJIA/CPqNeGPvrRoJHhJKAoMXR5dBlfXFwzMaQCLcB/s1600/Screenshot_4.png',FanArt,'')
    addDir('JAV_2_18+','http://www.navixtreme.com/playlist/161226/jav_2_18.plx',6,'https://4.bp.blogspot.com/-x0CKLquTVJI/Vy89zfCweTI/AAAAAAAA5B0/VifOUSNUyvAPV7rb4P-KXVGvoveFz0sawCLcB/s320/05.jpg',FanArt,'')
    addDir('JAV_1_18+','http://www.navixtreme.com/playlist/160836/jav_1_18.plx',6,'https://3.bp.blogspot.com/-Wgerd4sGW9U/VsPEU5XaUMI/AAAAAAAAz0o/gjaqWiFAgvQ/s320/72.jpg',FanArt,'')
    # addDir('','',6,xbmc.translatePath('special://home/addons/plugin.video.navixxx/resources/art/navixxx.png'),FanArt,'')
    # addDir('','',6,xbmc.translatePath('special://home/addons/plugin.video.navixxx/resources/art/navixxx.png'),FanArt,'')
    # addDir('','',6,xbmc.translatePath('special://home/addons/plugin.video.navixxx/resources/art/navixxx.png'),FanArt,'')
    # addDir('','',6,xbmc.translatePath('special://home/addons/plugin.video.navixxx/resources/art/navixxx.png'),FanArt,'')
	

def OpenUrl(url):
	req=urllib2.Request(url)
	req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response=urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link		
		
		
def GetAdultChannels(mname,murl):
	link=OpenUrl(murl)
	link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
	f=re.findall('<fanart>(.+?)</fanart>',link)
	match=re.compile('<title>([^<]+)</title.+?link>(.+?)</link.+?thumbnail>([^<]+)</thumbnail.+?fanart>(.+?)</fanart.+?info>(.+?)</info>').findall(link)		
	for name,url,thumb,fanart,description in match:
		addLink(name,url,'4',thumb,fanart,description)
		setView('', 'channels')
		
def GetAdultVideos(mname,murl):
	thumb = thumb
	link=OpenUrl(murl)
	link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('type=playlistname=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('type=playlistname=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('name=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('name=Sorted by user-assigned order','')
	match=re.compile('type=videoname=(.+?)URL=(.+?)player=.+?rating=.+?#').findall(link)
	for name,url in match:
		addLink2(name,url,'4','',fanart)
		setView('episodes', 'movies')
		
def GetAdultVideos2(mname,murl):
	link=OpenUrl(murl)
	link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('type=playlistname=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('type=playlistname=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('name=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('name=Sorted by user-assigned order','')
	match=re.compile('type=videoname=(.+?)thumb=(.+?)URL=(.+?)player=.+?rating=.+?#').findall(link)
	for name,thumb,url in match:
		addLink2(name,url,'4',thumb,fanart)
		setView('episodes', 'movies')
		
def GetAdultVideos3(mname,murl):
	link=OpenUrl(murl)
	link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('type=playlistname=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('type=playlistname=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('name=Sorted [COLOR=FF00FF00]by user-assigned order[/COLOR]','').replace('name=Sorted by user-assigned order','')
	match=re.compile('type=videoname=(.+?)thumb=(.+?)URL=(.+?)player=.+?rating=.+?#').findall(link)
	for name,thumb,url in match:
		addLink2(name,url,'4',thumb,fanart)
		setView('movies', 'movies')
		
def PlayAdultChannels(murl):
	ok=True
	playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	playlist.clear()
	stream_url = murl
	listitem = xbmcgui.ListItem(path=stream_url)
	listitem.setPath(stream_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	
	return ok
			
def PlayAdultItems(mname,murl,thumb):
	ok=True
	namelist=[]
	urllist=[]
	playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
	playlist.clear()			
	stream_url = murl
	urls = murl    
	hmf = urlresolver.HostedMediaFile(urls)
	if hmf:
		 xbmc.executebuiltin("XBMC.Notification(Please wait a moment!,Opening Link,10000)")
		 host = hmf.get_host()
		 dlurl = urlresolver.resolve(urls)
		 ResolvePinoyItems(mname,dlurl,'')

	else:
		 xbmc.sleep(1000)
		 ResolvePinoyItems(mname,murl,'')
	return ok


def ResolvePinoyItems(name,url,thumb):
	 params = {'url':url, 'name':name, 'thumb':thumb}
	 addon.add_video_item(params, {'title':name}, img=thumb)
	 liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumb)
	 xbmc.Player ().play(str(url), liz, False)
	 return
		
		
def addLink(name,url,mode,thumb,fanart,description):
        fanart = fanart
        params = {'url':url, 'mode':mode, 'name':name, 'thumb':thumb, 'fanart':fanart, 'description':description}        
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumb)
        liz.setInfo( type="Video", infoLabels={ "title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
		
		
def addLink2(name,url,mode,thumb,fanart):
        fanart = fanart
        params = {'url':url, 'mode':mode, 'name':name, 'thumb':thumb, 'fanart':fanart}        
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumb)
        liz.setInfo( type="Video", infoLabels={ "title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
		
		
def addDir(name,url,mode,thumb,fanart,description):
        fanart = fanart
        params = {'url':url, 'mode':mode, 'name':name, 'thumb':thumb, 'fanart':fanart, 'description':description}        
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumb)
        liz.setInfo( type="Video", infoLabels={ "title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
		
def setView(content, viewType):
        if content:
                xbmcplugin.setContent(int(sys.argv[1]), content)
        if ADDON.getSetting('auto-view') == 'true':
                xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
		
		

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param
              
params=get_params()



try: name=urllib.unquote_plus(params["name"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: mode=int(params["mode"])
except: pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
    iconimage = iconimage.replace(' ','%20')
except: pass
try: plot=urllib.unquote_plus(params["plot"])
except: pass
try:
    fanart=urllib.unquote_plus(params["fanart"])
    fanart = fanart.replace(' ','%20')
except: pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Thumb: "+str(iconimage)


if mode==None or url==None or len(url)<1:
        print ""
        MainDir()

elif mode==1:
    print ""
    GetAdultChannels(name,url)
	
elif mode==2:
    print ""
    GetAdultVideos(name,url)
	
elif mode==3:
    print ""
    GetAdultVideos2(name,url)

elif mode==4:
    PlayAdultItems(name,url,iconimage)

elif mode==5:
    PlayAdultChannels(url)
	
elif mode==6:
    print ""
    GetAdultVideos3(name,url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))        
