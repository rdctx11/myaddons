# -*- coding: utf-8 -*-
import xbmcgui, xbmc, xbmcaddon
from xbmcaddon import Addon


ADDON = Addon("plugin.video.pinoystreams")


kb =xbmc.Keyboard ('', 'heading', True)
kb.setHeading('Enter Current Password') # optional
kb.setHiddenInput(True) # optional
kb.doModal()
if (kb.isConfirmed()):
	curpass = kb.getText()
	if ADDON.getSetting('password')==curpass:
		kb =xbmc.Keyboard ('', 'heading', True)
		kb.setHeading('Enter New Password') # optional
		kb.setHiddenInput(True) # optional
		kb.doModal()
		if (kb.isConfirmed()):
			newpass = kb.getText()
			ADDON.setSetting('password', str(newpass))
			xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Pinoy Streams[/COLOR],[COLOR yellow]Password has been changed![/COLOR] ,3000)")
	else:
		dialog = xbmcgui.Dialog()
		ok = dialog.ok('Attention!', ' \n                          You entered a wrong password.\n                                       Please Try Again!')
	
	
	
	
	
	
