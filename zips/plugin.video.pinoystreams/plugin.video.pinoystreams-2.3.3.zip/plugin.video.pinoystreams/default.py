import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, xbmcaddon
import urlresolver
from addon.common.addon import Addon
import requests
from resources.lib import pinoytvlive
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.pinoystreams'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'pinoystreams'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"

BASEURL1 = 'https://www.pinoymoviepedia.su'
BASEURL2 = 'http://watchpinoymoviesonline.info/'
BASEURL3 = 'https://www.pinoymovieshub.co/'
TVURL = 'https://raw.githubusercontent.com/rdctx11/myaddons/master/myxmls/pinoytvestuary/PinoyTV.xml'
RADURL = 'https://raw.githubusercontent.com/rdctx11/myaddons/master/myxmls/pinoytvestuary/PinoyRadio.xml'

def MainDir():
    addDir('Pinoy Movies','url',2,ART + 'pinoymovies.jpg',FANART,'')
    addDir('Pinoy Teleserye','url',3,ART + 'pinoyteleserye.jpg',FANART,'')
    addDir('Pinoy TV Live',TVURL,200,ART + 'pinoytv.jpg',FANART,'')
    addDir('Pinoy Radio Live',RADURL,200,ART + 'pinoyradio.jpg',FANART,'')
    addDir('PBA Replays','https://pbafullreplay.blogspot.ae/',90,ART + 'pbareplay.jpg',FANART,'')
    setView('addons', 'cat-view')
	
    if len(addon.get_setting('notify')) > 0:
        addon.set_setting('notify', str(int(addon.get_setting('notify')) + 1))
    else:
        addon.set_setting('notify', "1")
    if int(addon.get_setting('notify')) == 1:
        xbmcgui.Dialog().notification('[B][COLOR cornflowerblue]PINOY STREAMS is provided by NIELDC[/COLOR][/B]','[B][COLOR yellow]Enjoy Watching... Salamat po![/COLOR][/B]',ICON,13000,False)
    elif int(addon.get_setting('notify')) == 9:
        addon.set_setting('notify', "0")
    if int(addon.get_setting('notify')) > 1:
		try:
			OPEN = Open_Url('https://pastebin.com/raw/HWvTr4NC')
			Regex = re.compile('<msg>(.+?)</msg>',re.DOTALL).findall(OPEN)
			for msg in Regex:
				if addon.get_setting('message')==msg:
					return
				else:
					addon.set_setting('message', str(msg))
					xbmcgui.Dialog().ok('Pinoy Streams', str(addon.get_setting('message')))
					return
		except:pass
	
def Movies_Cat():
    addDir('Search','url',6,ART + 'searchpinoymovies.jpg',FANART,'')
    addDir('Pinoy Movie Pedia','url',10,ART + 'moviepedia.jpg',FANART,'')
    addDir('Pinoy Movies Online','url',20,ART + 'watchpinoy.jpg',FANART,'')
    # addDir('Pinoy Movies Hub','url',33,ART + 'pinoymovieshub.jpg',FANART,'')
    addDir('Full Pinoy Movies','http://www.fullpinoymovies.net/',27,ART + 'fullpinoymovies.jpg',FANART,'')
    addDir('HDTS.ME','url',39,ART + 'hdts.jpg',FANART,'')
    addDir('Pinoy Movies Stream','http://pinoymovies.stream/movies/',30,ART + 'pinoymoviestream.jpg',FANART,'')
    addDir('Restricted Movies','url',5,ART + 'xpinoymovies.jpg',FANART,'')
    setView('addons', 'cat-view')
	
def Teleserye_Cat():
    addDir('Kapamilya Shows','http://pacitalaflakes.blogspot.com/search/label/ABS-CBN?m=0',60,ART + 'kapamilya.jpg',FANART,'')
    addDir('Kapuso Shows','http://www.kapuso.be/search/label/GMA?&max-results=24',60,ART + 'kapuso.jpg',FANART,'')
    addDir('Lambingan TV','http://www.lambingan.su/blog/',65,ART + 'lambingan.jpg',FANART,'')
    # addDir('Teleserye Replay','https://teleseryereplay.org',68,ART + 'teleseryereplay.jpg',FANART,'')
    # addDir('Teleserye Tambayan','http://www.pinoyteleseryetambayan.com/',80,ART + 'teleseryetambayan.jpg',FANART,'')
    addDir('Pinoy Tambayan','https://pinoytambayantv.su/',75,ART + 'pinoytambayan.jpg',FANART,'')
    addDir('Pinoy-TV','http://www.pinoy-tv.ws/',83,ART + 'pinoytvws.jpg',FANART,'')
    # addDir('Mag TV Na','http://www.magtvnaph.com/',86,ART + 'magtvna.jpg',FANART,'')
    setView('addons', 'cat-view')
	
	
###############  PINOY MOVIES  ###############        
        
#### rated-r pinoy movies ####

def xpinoymovies_cat():
    addDir('Restricted Movies 1','https://www.pinoymovieshub.com/genre/sexy/',34,ART + 'xpinoymovies.jpg',FANART,'')
    addDir('Restricted Movies 2',BASEURL2+'category/x-rated/',21,ART + 'xpinoymovies.jpg',FANART,'')
    setView('addons', 'cat-view')
        
        
#### pinoymoviepedia.su ####

def moviepedia_cat():
    addDir('Pinoy Movies',BASEURL1+'/category/tagalog-movies/',11,ART + 'moviepedia-cat1.jpg',FANART,'')
    addDir('Hollywood Movies',BASEURL1+'/category/hollywood-movies/',11,ART + 'moviepedia-cat2.jpg',FANART,'')
    addDir('Hollywood Bluray',BASEURL1+'/category/bluray/',11,ART + 'moviepedia-cat3.jpg',FANART,'')
    addDir('Asian Movies',BASEURL1+'/category/asian-movies/',11,ART + 'moviepedia-cat4.jpg',FANART,'')
    addDir('Search Moviepedia','url',13,ART + 'moviepedia-search.jpg',FANART,'')
    setView('addons', 'cat-view')
    
def moviepedia_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<li class="border-radius.+?src="(.+?)".+?href="(.+?)" title="(.+?)">',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        icon = icon.replace('-210x142','').replace('-199x142','')
        addDir('%s' %name,url,12,icon,FANART,'')
    np = re.compile('rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,11,ART + 'pagemov.jpg',FANART,'')
    setView('movies', 'mov-view')
    
def moviepedia_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        url = url.replace('https://href.li/?','')
        if 'dailymotion' in Regex:
            url = 'http:' + url
        if urlresolver.HostedMediaFile(url).valid_url():    
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('%s' %name2,url,100,iconimage,iconimage,name)
    linkView()

def moviepedia_search():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ','+')
            url = BASEURL1 + '/?s=' + search
            moviepedia_content(url)

#### watchpinoymoviesonline.info ####

def watchpinoy_cat():
    addDir('Latest Movies',BASEURL2+'category/latest/',21,ART + 'watchpinoy-cat1.jpg',FANART,'')
    addDir('Classic Movies',BASEURL2+'category/pinoy-classic-movies/',21,ART + 'watchpinoy-cat2.jpg',FANART,'')
    addDir('Movies by Genre',BASEURL2,22,ART + 'watchpinoy-cat3.jpg',FANART,'')
    addDir('All Movies',BASEURL2+'category/pinoy-movies/',21,ART + 'watchpinoy-cat4.jpg',FANART,'')
    addDir('Tagalog Dubbed Movies',BASEURL2+'category/tagalog-dubbed/',21,ART + 'watchpinoy-cat5.jpg',FANART,'')
    setView('addons', 'cat-view')
    
def watchpinoy_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="loop-header">(.+?)</div><!-- end #content -->',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a class="clip-link".+?href="(.+?)".+?<img src="(.+?)" alt="(.+?)".+?class="entry-summary">(.+?)</p>',re.DOTALL).findall(str(Regex))
    for url,icon,name,description in Regex2:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;','&').replace('&#8230;','...')
        description = description.replace('&#8217;','\'').replace('&#8211;','-').replace('&#038;','&').replace('&#124;','|').replace('\\r','  ').replace('\\n',' ')
        addDir('%s' %name,url,100,icon,FANART,description)
    np = re.compile('<a class="nextpostslink" rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,21,ART + 'pagemov.jpg',FANART,'')
    setView('movies', 'mov-view')     

def watchpinoy_genre(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="sub-menu">(.+?)<!-- end #main-nav -->',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        if 'Ghost Fighter' not in name:
            if 'Slam Dunk' not in name:
                if 'Pinoy Classic' not in name:
                    if 'Latest' not in name:
                        if 'Live Stream' not in name:
							if 'Daimos' not in name:
								if 'Hunter' not in name:
									if 'X Rated' not in name:
										if 'Tagalog Dubbed' not in name:
											addDir('%s' %name,url,21,ART + 'watchpinoy.jpg',FANART,'')

def watchpinoy_live(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="item-video".+?href="(.+?)".+?<img src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon in Regex:
        if 'http' not in icon:
            icon = 'http:' + icon
        name = url.split('//')[1]
        name = name.split('/')[1].replace('-',' ').replace('live streaming','(Stream) ').title()
        addDir('%s' %name,url,24,icon,FANART,'')
    setView('addons', 'epi-view')   

def watchpinoylive_resolve(url):
    OPEN = Open_Url(url)
    if '//livestream01' in OPEN:
       url = re.compile('var video="(.+?)"',re.DOTALL).findall(OPEN)[0]
    elif 'file: ' in OPEN:
        try:
            url = re.compile('file: "(.+?)"',re.DOTALL).findall(OPEN)[0]
        except:
            url = re.compile("file: '(.+?)'",re.DOTALL).findall(OPEN)[0]
    else:
        url = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)[0]
        url = url.replace('?autoplay=1&wmode=opaque&rel=0&showinfo=0&modestbranding=0','')
    url1 = urlresolver.resolve(url)
    if url1:
        try:
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title':description})
            liz.setProperty("IsPlayable","true")
            liz.setPath(url1)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        except: pass
    else:
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 

#### fullpinoymovies.net ####
 
def fullpinoymovies_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<h1>Content recently added</h1>(.+?)class='page larger'",re.DOTALL).findall(OPEN)
    Regex2 = re.compile('class="item".+?href="(.+?)".+?src="(.+?)" alt="(.+?)".+?class="ttx"> (.+?)<div class="degradado">',re.DOTALL).findall(str(Regex))
    for url,icon,name,description in Regex2:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#038;','&')
        description = description.replace('&#8217;','\'').replace('&#8211;','-').replace('&#038;','&').replace('&#124;','|').replace('\\n','; ')
        addDir('%s' %name,url,28,icon,FANART,description)
    np = re.compile('class="pag_b".+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,27,ART + 'pagemov.jpg',FANART,'')
    setView('movies', 'mov-view')

def fullpinoymovies_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
            name2 = name2.replace('Oload','Openload')
        except:pass
        addDir('%s' %name2,url,100,iconimage,FANART,'[B]%s[/B]' %name + '\n\n' + description)
    linkView() 

#### pinoymovies.stream.net ####
 
def pinoymoviestream_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div data-movie-id.+?href="(.+?)".+?oldtitle="(.+?)".+?<img data-original="(.+?)".+?<p>(.+?)</p>',re.DOTALL).findall(OPEN)
    for url,name,icon,description in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#038;','&')
        description = description.replace('&#8217;','\'').replace('&#8216;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...').replace('&#8220;','\"').replace('&#8221;','\"').replace('&#8212;','--').replace('&#8206;',' ').replace('&nbsp;',' ').replace('\n','')
        addDir('%s' %name,url,31,icon,FANART,description)
    np = re.compile('content="website".+?<meta property="og:url" content="(.+?)"',re.DOTALL).findall(OPEN)
    for url1 in np:
        if 'page' not in url1:
			url = url1 + '/page/2'
			addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,30,ART + 'pagemov.jpg',FANART,'')
    np2 = re.compile('content="website".+?<meta property="og:url" content="http://pinoymovies.stream/movies/page/(.+?)"',re.DOTALL).findall(OPEN)
    for pageno in np2:
        url = 'http://pinoymovies.stream/movies/page/' + str(int(pageno) + 1)
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,30,ART + 'pagemov.jpg',FANART,'')
    setView('movies', 'mov-view')

def pinoymoviestream_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
            name2 = name2.replace('Oload','Openload')
        except:pass
        addDir('%s' %name2,url,100,iconimage,FANART,'[B]%s[/B]' %name + '\n\n' + description)
    linkView()
	
        
#### pinoymovieshub.com ####

def pinoymovieshub_cat():
    addDir('All Pinoy Movies',BASEURL3+'movies/',34,ART + 'pinoymovieshub-cat1.jpg',FANART,'')
    addDir('Recommended Movies',BASEURL3+'genre/featured/',34,ART + 'pinoymovieshub-cat2.jpg',FANART,'')
    addDir('Upcoming Movies',BASEURL3+'genre/family/',34,ART + 'pinoymovieshub-cat4.jpg',FANART,'')
    addDir('Pinoy Romantic Movies',BASEURL3+'genre/romance/',34,ART + 'pinoymovieshub-cat5.jpg',FANART,'')
    addDir('Pinoy Comedy Movies',BASEURL3+'genre/comedy/',34,ART + 'pinoymovieshub-cat6.jpg',FANART,'')
    addDir('Pinoy Horror Movies',BASEURL3+'genre/horror/',34,ART + 'pinoymovieshub-cat7.jpg',FANART,'')
    addDir('Tagalog Dubbed',BASEURL3+'genre/family/',34,ART + 'pinoymovieshub-cat4.jpg',FANART,'')
    addDir('Genres',BASEURL3,36,ART + 'pinoymovieshub-cat8.jpg',FANART,'')
    addDir('Search','url',37,ART + 'pinoymovieshub-search.jpg',FANART,'')
    setView('addons', 'cat-view')
    
def pinoymovieshub_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h1>Movies</h1>(.+?)class="pagination"',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('class="item movies".+?src="(.+?)".+?alt="(.+?)".+?class="quality">(.+?)</span>.+?href="(.+?)".+?class="texto">(.+?)</div>',re.DOTALL).findall(str(Regex))
    for icon,name,name2,url,description in Regex2:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...')
        description = description.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&rsquo;','\'').replace('&lsquo;','\'').replace('&ldquo;','\"').replace('&rdquo;','\"').replace('&#8220;','\"').replace('&#8221;','\"').replace('&#8230;','...')
        icon = icon.replace('-185x278','')
        addDir('%s' %name,url,35,icon,FANART,description)
    np = re.compile("rel='next' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,34,ART + 'pagemov.jpg',FANART,'')
    setView('movies', 'mov-view')
	
def pinoymovieshubsearch_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="result-item".+?href="(.+?)".+?src="(.+?)".+?alt="(.+?)".+?class="contenido"><p>(.+?)</p>',re.DOTALL).findall(OPEN)
    for url,icon,name,description in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...')
        description = description.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('<strong>','').replace('</strong>','').replace('&rsquo;','\'').replace('&lsquo;','\'').replace('&ldquo;','\"').replace('&rdquo;','\"').replace('&#8230;','...')
        icon = icon.replace('-185x278','').replace('-150x150','')
        addDir('%s' %name,url,35,icon,FANART,description)
    np = re.compile("rel='next' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,38,ART + 'pagemov.jpg',FANART,'')
    setView('movies', 'mov-view')
    
def pinoymovieshub_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="metaframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        if urlresolver.HostedMediaFile(url).valid_url():    
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('%s' %name2,url,100,iconimage,iconimage,'[B]%s[/B]' %name + '\n\n' + description)
    linkView()
    
def pinoymovieshub_genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('Sign Up</a>.+?Genres(.+?)Requests</a>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('genres menu-item.+?href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        if 'Sexy' not in name:
			addDir('%s' %name,url,34,ART+'genres.png',FANART,'')
    linkView()

def pinoymovieshub_search():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ','+')
            url = BASEURL3 + '?s=' + search
            pinoymovieshubsearch_content(url)
        
#### hdts.me ####

def hdts_cat():
    addDir('Pinoy Latest Movies','https://www.hdts.me/movies/',40,ART + 'hdts-cat1.jpg',FANART,'')
    addDir('Pinoy Klasik Movies','https://www.hdts.me/genre/pinoy-klasik/',40,ART + 'hdts-cat2.jpg',FANART,'')
    addDir('Search','url',42,ART + 'hdts-search.jpg',FANART,'')
    setView('addons', 'cat-view')
    
def hdts_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('data-movie-id.+?href="(.+?)".+?oldtitle="(.+?)".+?data-original="(.+?)".+?<p>(.+?)<!-- AddThis',re.DOTALL).findall(OPEN)
    for url1,name,icon,description in Regex:
        name = name.replace('Watch ','').replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...')
        description = description.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...').replace('&#8220;','\"').replace('&#8221;','\"')
        addDir('%s' %name,url1,41,icon,FANART,description)		
    np = re.compile('rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,40,ART + 'pagemov.jpg',FANART,'')
    setView('movies', 'mov-view')
    
def hdts_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<IFRAME SRC="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        if urlresolver.HostedMediaFile(url).valid_url():    
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('%s' %name2,url,100,iconimage,iconimage,name)
    altlinks = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in altlinks:
        if urlresolver.HostedMediaFile(url).valid_url():    
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('%s' %name2,url,100,iconimage,iconimage,'[B]%s[/B]' %name + '\n\n' + description)
    linkView()	

def hdts_search():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ','+')
            url = 'https://www.hdts.me/?s=' + search
            hdts_content(url)	
		
###############  TELESERYE  ###############

#### kapuso.be / pacitalaflakes ####
 
def absgma_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<a class='thumbx' href='(.+?)' title='(.+?)'.+?src='(.+?)'/></a>",re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&')
        icon = icon.replace('s72-c/','')
        addDir('%s' %name,url,61,icon,FANART,'')
    np = re.compile("<a class='blog-pager-older-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,60,ART + 'page.jpg',FANART,'')
    setView('albums', 'epi-view')

def absgma_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<[iI][fF][rR][aA][mM][eE] [sS][rR][cC]="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
        except:pass
        addDir('%s' %name2,url,100,iconimage,iconimage,name)
    altlinks = re.compile('DM.player.+?"player(.+?)".+?video: "(.+?)"',re.DOTALL).findall(OPEN)
    for name2,url in altlinks:
        addDir('Part %s' %name2,'http://www.dailymotion.com/embed/video/%s'%url,100,iconimage,FANART,name)
    linkView()
    
#### lambingan.su ####

def lambingan_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('div class="item post.+?href="(.+?)".+?rel="(.+?)".+?alt="(.+?)".+?<p>(.+?)</p>',re.DOTALL).findall(OPEN)
    for url,icon,name,description in Regex:
        if 'http' not in icon:
            icon = 'http:' + icon
            icon = icon.replace('-549x316_c','')
        description = description.replace('&#8217;','\'').replace('&#8216;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...').replace('&#8220;','\"').replace('&#8221;','\"').replace('&#8212;','--').replace('&#8206;',' ').replace('&nbsp;',' ')
        addDir('%s' %name,url,66,icon,icon,description)
    np = re.compile("rel='next' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        if 'http' not in url:
            url = 'http:' + url
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,65,ART + 'page.jpg',FANART,'')
    setView('episodes', 'epi-view')
    
def lambingan_links(name,url):
    OPEN = Open_Url(url)
    i=1
    Regex = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
		if 'facebook' not in url:
			if 'http' not in url:
				url = 'http:' + url
			if '/dm' in url:
				name2 = 'Dailymotion (Full Video)'
			elif '/mo-' in url:
				name2 = 'Openload (Full Video)'
			elif '/embed-mo' in url:
				name2 = 'Openload (Full Video)'
			elif '/all' in url:
				name2 = 'Estream / Vidoza (Full Video)'
			elif '/embed-all' in url:
				name2 = 'Estream / Vidoza (Full Video)'
			elif '/or' in url:
				name2 = 'Streamango (Full Video)'
			elif '/embed-or' in url:
				name2 = 'Streamango (Full Video)'
			elif '/tb-' in url:
				name2 = 'CDN (M3U8) (Full Video)'
			elif '/tb2-' in url:
				name2 = 'CDN (M3U8) (Full Video)'
			elif '/jw-' in url:
				name2 = 'Nodefiles (MP4) (Full Video)'
			else:
				name2= 'Video Part ' + str(i)
				i=i+1
			addDir('%s' %name2,url,67,iconimage,iconimage,name)			
				
    linkView()

def lambingan_resolve(url):
    if 'http' not in url:
        url = 'http:' + url
    if 'watchnew' in url:
        OPEN = Open_Url(url)
        try:
            url = re.compile('<[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"',re.DOTALL).findall(OPEN)[0]
            if 'http:' not in url:
                url = 'http:' + url
                stream_url = urlresolver.resolve(url)
            else:
                stream_url = urlresolver.resolve(url)
        except:
            url = re.compile('<div class=.+?container.+?href="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
    elif 'linkshare' in url:
		OPEN = Open_Url(url)
		url = re.compile('<source src="(.+?)"',re.DOTALL).findall(OPEN)[0]
		stream_url = url
    # elif 'dailymotion' in url:
		# url = 'http:' + url
		# stream_url = urlresolver.resolve(url)
    elif 'lambingan' in url:
        Holder = Open_Url(url)
        if '/dm' in url:
            try:
				url = re.compile('"file": "(.+?)"',re.DOTALL).findall(Holder)[0]
				stream_url = url
            except:
				url = re.compile('class="bio".+?src="(.+?)"',re.DOTALL).findall(Holder)[0]
				if 'dailymotion' in url:
					url = 'http:' + url
					stream_url = urlresolver.resolve(url)
				elif 'linkshare' in url:
					OPEN = Open_Url(url)
					url = re.compile('<source src="(.+?)"',re.DOTALL).findall(OPEN)[0]
					stream_url = url
        elif '/mo-' in url:
            url = re.compile('class="bio".+?href="(.+?)"',re.DOTALL).findall(Holder)[0]
            stream_url = urlresolver.resolve(url)
        elif '/embed-mo' in url:
            url = re.compile('<a href="(.+?)".+?img border',re.DOTALL).findall(Holder)[0]
            stream_url = urlresolver.resolve(url)
        elif '/all' in url:
            url = re.compile('class="bio".+?href="(.+?)"',re.DOTALL).findall(Holder)[0]
            stream_url = urlresolver.resolve(url)
        elif '/embed-all' in url:
            url = re.compile('<a href="(.+?)".+?img border',re.DOTALL).findall(Holder)[0]
            stream_url = urlresolver.resolve(url)
        elif '/or' in url:
            url = re.compile('class="bio".+?href="(.+?)"',re.DOTALL).findall(Holder)[0]
            stream_url = urlresolver.resolve(url)
        elif '/embed-or' in url:
            url = re.compile('<a href="(.+?)".+?img border',re.DOTALL).findall(Holder)[0]
            stream_url = urlresolver.resolve(url)
        elif '/tb' in url:
            url = re.compile('class="bio".+?src="(.+?)"',re.DOTALL).findall(Holder)[0]
            stream_url = url
        elif '/file' in url:
            url = re.compile('"file": "(.+?)"',re.DOTALL).findall(Holder)[0]
            stream_url = url
        elif '/jw-' in url:
            url = re.compile('"file": "(.+?)"',re.DOTALL).findall(Holder)[0]
            stream_url = url
        elif '/embed-ok' in url:
            url = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(Holder)[0]
            url = 'http:' + url
            stream_url = urlresolver.resolve(url)
        elif 'ok.ru/videoembed' in url:
            # url = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(Holder)[0]
            url = 'https:' + url
            stream_url = urlresolver.resolve(url)
        else:
			try:
				url = re.compile('"file": "(.+?)"',re.DOTALL).findall(Holder)[0]
				stream_url = url		
			except:
				url = re.compile('class="bio".+?href="(.+?)"',re.DOTALL).findall(Holder)[0]
				stream_url = urlresolver.resolve(url)
    else:
        stream_url = urlresolver.resolve(url)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	
#### teleseryereplay.org ####	

def teleseryereplay_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="clip-link".+?title="(.+?)" href="(.+?)".+?src="(.+?)".+?class="entry-summary">(.+?)</p>',re.DOTALL).findall(OPEN)
    for name,url,icon,description in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        description = description.replace('&#8217;','\'').replace('&#8216;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...').replace('&#8220;','\"').replace('&#8221;','\"').replace('&#8212;','--').replace('&#8206;',' ').replace('&nbsp;',' ').replace('\n','').replace('[&hellip;]','...').replace('"','').replace('    ',' ').replace('<','-')
        addDir('%s' %name,url,69,icon,icon,description)
    np = re.compile('link rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,68,ART + 'page.jpg',FANART,'')
    setView('episodes', 'epi-view')
    
def teleseryereplay_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        url = url.replace('https://href.li/?','')
        if urlresolver.HostedMediaFile(url).valid_url():
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('%s' %name2,url,100,iconimage,iconimage,name)
    altlinks = re.compile('<iframe frameborder.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    if altlinks:
		i=1
		for url in altlinks:
			try:
				name2 = url.split('//')[1].replace('www.','')
				name2 = name2.split('/')[0].split('.')[0].title()
			except:pass
			if len(altlinks)>1:
				name1= name2 + ' - Part '+ str(i)
				i=i+1
				addDir('%s' %name1,url,100,iconimage,iconimage,name)
			else:
				addDir(name2,url,100,iconimage,iconimage,name)
			
    linkView()
	
	
#### https://pinoytambayantv.su/ ####

def pinoytambayan_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('data-layzr="(.+?)".+?<header>.+?href="(.+?)" title="(.+?)"',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('Full Episode in HD','').replace('Full Episode In HD','').replace('Full Episode HD','')
        addDir('%s' %name,url,76,icon,icon,'')
    np = re.compile('rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,75,ART + 'page.jpg',FANART,'')
    setView('episodes', 'epi-view')
    
def pinoytambayan_links(name,url):
    OPEN = Open_Url(url)
    if 'Part' in OPEN:
		Regex = re.compile("file: '(.+?)'.+?Part 1</",re.DOTALL).findall(OPEN)
		for url in Regex:
			addDir(name + ' - Full Video',url,77,iconimage,iconimage,name)
    else:
		Regex = re.compile("file: '(.+?)'.+?image:",re.DOTALL).findall(OPEN)
		for url in Regex:
			addDir(name + ' - Full Video',url,77,iconimage,iconimage,name)
    Regex2 = re.compile("Part.+?file: '(.+?)'",re.DOTALL).findall(OPEN)
    i=1
    for url in Regex2:
		if len(Regex2)>1:
			name2= name + ' - Part '+ str(i)
			i=i+1
			addDir('%s' %name2,url,77,iconimage,iconimage,name)
		else:
			addDir(name + ' - Full Video',url,77,iconimage,iconimage,name)
		# name2= name + ' - Part '+ str(i)
		# i=i+1
		# addDir('%s' %name2,url,77,iconimage,iconimage,name)
    altlinks = re.compile('<iframe.+?src="(.+?)".+?allowfullscreen',re.DOTALL).findall(OPEN)
    i=1
    for url in altlinks:
		if len(altlinks)>1:
			name2= name + ' - Part '+ str(i)
			i=i+1
			addDir('%s' %name2,url,77,iconimage,iconimage,name)
		else:
			addDir(name,url,77,iconimage,iconimage,name)
    linkView()
	
def pinoytambayan_resolve(url):
	if 'streamable.com' in url:
		stream_url = url
	elif urlresolver.HostedMediaFile(url).valid_url():
		stream_url = urlresolver.resolve(url)
	else:
		stream_url = url
	liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo(type="Video", infoLabels={"Title": description})
	liz.setProperty("IsPlayable","true")
	liz.setPath(stream_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	
	
#### pinoyteleseryetambayan.com ####

'''def teleseryetambayan_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="td-pulldown-size">TELESERYE(.+?)</body>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<div class="td-module-thumb".+?href="(.+?)".+?title="(.+?)".+?src="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,name,icon in Regex2:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        icon = icon.replace('-100x70','')
        addDir('%s' %name,url,81,icon,icon,'')
    setView('episodes', 'epi-view')
    
def teleseryetambayan_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
        except:pass
        if 'relaxpinas.com' not in url:
			addDir('%s' %name2,url,100,iconimage,iconimage,name)        
        if 'relaxpinas.com' in url:
			OPEN = Open_Url(url)
			Regex = re.compile('var playlis(.+?)];',re.DOTALL).findall(OPEN)
			match = re.compile("'(.+?)',").findall(str(Regex))
			if match:
				i=1
				for url in match:
					if len(match) >1:
						name1= name2 + ' - Part '+ str(i)
						i=i+1
						addDir('%s' %name1,url,77,iconimage,iconimage,name)
					else:
						addDir('Relaxpinas',url,77,iconimage,iconimage,name)
				
    linkView()'''	
	
	
#### pinoy-tv.ws (GMA Shows) ####

def pinoytvws_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<a class="entry.+?href="(.+?)".+?src="(.+?)" alt=(.+?) title="(.+?)".+?title=',re.DOTALL).findall(OPEN)
    for url,icon,description,name in Regex:
        icon = 'http://' + icon
        name = name.replace('&#8217;','\'').replace('&#8216;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        if '""' in description:
			description = 'No information available'
        else:
			description = description.replace('&#8217;','\'').replace('&#8216;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...').replace('&#8220;','\"').replace('&#8221;','\"').replace('&#8212;','--').replace('&#8206;',' ').replace('&nbsp;',' ').replace('\n','').replace('[&hellip;]','...').replace('"','')
        addDir('%s' %name,url,84,icon,icon,description)
    np = re.compile('class="nextpostslink" rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page >>>[/COLOR][/B]',url,83,ART + 'page.jpg',FANART,'')
    setView('episodes', 'epi-view')
    
def pinoytvws_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="tabbertab".+?<h3>(.+?)</h3>.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for name2,url in Regex:
		if 'http' not in url:
			url = 'http:' + url
		else:
			url = url
		addDir(name + ' - %s' %name2,url,77,iconimage,iconimage,'[B]%s[/B]' %name + '\n\n' + description)
    altlinks = re.compile('class="tabbertab".+?<h2>(.+?)</h2>.+?source: "(.+?)"',re.DOTALL).findall(OPEN)
    for name2,url in altlinks:
		if 'http' not in url:
			url = 'http:' + url
		else:
			url = url
		addDir(name + ' - %s' %name2,url,77,iconimage,iconimage,'[B]%s[/B]' %name + '\n\n' + description)
    altlinks2 = re.compile('class="tabbertab".+?<h2>(.+?)</h2>.+?file: "(.+?)"',re.DOTALL).findall(OPEN)
    for name2,url in altlinks2:
		if 'http' not in url:
			url = 'http:' + url
		else:
			url = url
		addDir(name + ' - %s' %name2,url,77,iconimage,iconimage,'[B]%s[/B]' %name + '\n\n' + description)
    altlinks3 = re.compile('<h2>(.+?)</h2>.+?<iframe.+?src="(.+?)".+?allowfullscreen',re.DOTALL).findall(OPEN)
    for name2,url in altlinks3:
		if 'http' not in url:
			url = 'http:' + url
		else:
			url = url
		addDir(name + ' - %s' %name2,url,77,iconimage,iconimage,'[B]%s[/B]' %name + '\n\n' + description)
				
    linkView()	
	
	
#### magtvnaph.com ####

def magtvnaph_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("class='post-title.+?href='(.+?)'>(.+?)</a>.+?src=(.+?) width=.+?justify;.+?>(.+?)</div>",re.DOTALL).findall(OPEN)
    for url,name,icon,description in Regex:
        icon = icon.replace('"','')
        name = name.replace('&#8217;','\'').replace('&#8216;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('\n','')
        if 'magtvnaph' in description:
			description = 'No information available'
        else:			
			description = description.replace('&#8217;','\'').replace('&#8216;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...').replace('&#8220;','\"').replace('&#8221;','\"').replace('&#8212;','--').replace('&#8206;',' ').replace('&nbsp;',' ').replace('\n','')
        addDir(name,url,87,icon,icon,description)
    setView('episodes', 'epi-view')
    
def magtvnaph_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('id="Disclaimer" class="tabcontent"(.+?)<center>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(str(Regex))
    i=1
    for url in Regex2:
		if len(Regex2)>1:
			name2= name + ' - Part '+ str(i)
			i=i+1
			addDir('%s' %name2,url,100,iconimage,iconimage,'[B]%s[/B]' %name + '\n\n' + description)
		else:
			addDir(name + ' - Full Video',url,100,iconimage,iconimage,'[B]%s[/B]' %name + '\n\n' + description)
				
    linkView()
    
###############################

#### PBA REPLAYS ####
def pbareplay_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<div class='post-outer'>.+?<meta content='(.+?)' itemprop='image_url'.+?href='(.+?)'>(.+?)</a>.+?trbidi=.+?on.+?>(.+?)<br>",re.DOTALL).findall(OPEN) 
    for icon,url,name,description in Regex:
        description = description.replace('&#8217;','\'').replace('&#8211;','-').replace('&#038;','&').replace('&amp;','&').replace('<div dir="ltr"','').replace(' style="text-align: left;"','').replace(' trbidi="on">','').replace('<br>','').replace('','').replace('<div class="separator" style="clear: both; text-align: center;">','')
        addDir('%s' %name,url,91,icon,icon,description)
    tp = re.compile("<a class='home-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in tp:
        addDir('[B][COLOR lime]Top Page[/COLOR][/B]',url,90,ART + 'pbareplay.jpg',ART + 'pba.jpg','')
    pp = re.compile("<a class='blog-pager-newer-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in pp:
        addDir('[B][COLOR lime]Previous Page[/COLOR][/B]',url,90,ART + 'pbareplay.jpg',ART + 'pba.jpg','')
    np = re.compile("<a class='blog-pager-older-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR lime]Next Page[/COLOR][/B]',url,90,ART + 'pbareplay.jpg',ART + 'pba.jpg','')
    linkView()

def pbareplay_links(name,url):
	OPEN = Open_Url(url)
	Regex = re.compile("1ST QUARTER(.+?)<div class='post-footer'>",re.DOTALL).findall(OPEN)
	match = re.compile('<iframe.+?src="(.+?)".+?</iframe>',re.DOTALL).findall(str(Regex))	
	if match:
		i=0
		for url in match:
			if 'dailymotion' in match:
				url = 'http:' + url
			else:
				url = url
			if len(match) >1:
				i +=1
				label=i
				name2 = '[B][COLOR lime]%s QUARTER[/COLOR][/B]' %label
				name2 = name2.replace('1','1ST').replace('2','2ND').replace('3','3RD').replace('4','4TH').replace('5 QUARTER','1ST OVERTIME').replace('6 QUARTER','2ND OVERTIME').replace('7 QUARTER','3RD OVERTIME')
				addDir('%s' %name2,url,100,iconimage,iconimage,name)
			else:
				addDir(name,url,100,iconimage,iconimage,'[B]%s[/B]' %name + '\n\n' + description)
	linkView()

def pbareplay_resolve(url):
    hosts = []
    stream_url = []
    host = ''
    try:
        OPEN = Open_Url(url)
        count = 0
        links = re.compile("1ST QUARTER(.+?)<div class='post-footer'>",re.DOTALL).findall(OPEN)
        match = re.compile('<iframe.+?src="(.+?)".+?</iframe>',re.DOTALL).findall(str(links))
        for link in match:
                count +=1 
                label = count
                host = '[B][COLOR lime]%s QUARTER[/COLOR][/B]' %label				
                host= host.replace('1','1ST').replace('2','2ND').replace('3','3RD').replace('4','4TH').replace('5 QUARTER','1ST OVERTIME').replace('6 QUARTER','2ND OVERTIME').replace('7 QUARTER','3RD OVERTIME')				
                hosts.append(host)
                stream_url.append(link)
        if len(match) >1:
                dialog = xbmcgui.Dialog()
                ret = dialog.select('Please Select Quarter',hosts)
                if ret == -1:
                    return
                elif ret > -1:
                        url = stream_url[ret]
        else:
            url = re.compile('iframe.+?src="(.+?)"').findall(OPEN)[0]
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR cornflowerblue]No Links Available[/COLOR] ,5000)")
    url = 'http:' + url  
    try:    
        stream_url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass

###############  PINOY TV  ###############
def pinoytv_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<title>(.+?)</title>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>',re.DOTALL).findall(OPEN)
    for name,url,icon in Regex:
        if '.xml' in url:
            addDir('%s' %name,url,97,icon,FANART,'')
        else:
            addDir('%s' %name,url,98,icon,FANART,'')
    setView('addons', 'epi-view')
	
def pinoytv_links(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<title>(.+?)</title>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>',re.DOTALL).findall(OPEN)
    for name,url,icon in Regex:
        if '.xml' in url:
            addDir('%s' %name,url,97,icon,FANART,'')
        else:
            addDir('%s' %name,url,98,icon,FANART,'')
    setView('addons', 'epi-view')

def pinoytv_resolve(url):
    try:
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)   
    except:pass   
	
	
###############  PINOY RADIO  ###############
    
def pinoyradio_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<li class="item.+?href="(.+?)" title="(.+?)".+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;','&').replace('&#8230;','...')
        addDir('%s' %name,url,100,icon,FANART,'')
    setView('addons', 'epi-view')  
	
################# Pinoy Movies Search ################## 

def MovieSearchAll():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
		search = keyb.getText().replace(' ','+')
		if search == '':
			exit()
		else:		
			OPEN = Open_Url('https://pastebin.com/raw/xS61wViU')
			Regex = re.compile('<item title=.+?<link>(.+?)</link>',re.DOTALL).findall(OPEN)
			for searchurl in Regex:
				try:
					if 'pinoymoviepedia' in searchurl:
						url = searchurl + '/?s=' + search
						OPEN = Open_Url(url)
						Regex = re.compile('<div id="content">(.+?)listing-tube">',re.DOTALL).findall(OPEN)
						Regex2 = re.compile('<li class="border-radius.+?src="(.+?)".+?href="(.+?)" title="(.+?)">',re.DOTALL).findall(OPEN)
						for icon,url,name in Regex2:
							name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
							icon = icon.replace('-210x142','').replace('-199x142','')
							for result in Regex:
								if 'Sorry' not in result:
									addDir('%s' %name + ' - [COLOR yellow]Pinoy Movie Pedia[/COLOR]',url,12,icon,FANART,'')
								else:
									pass
					elif 'watchpinoymoviesonline' in searchurl:
						url = searchurl + '/?s=' + search
						OPEN = Open_Url(url)
						Regex = re.compile('<div class="loop-header">(.+?)</div><!-- end #content -->',re.DOTALL).findall(OPEN)
						Regex2 = re.compile('<a class="clip-link".+?href="(.+?)".+?<img src="(.+?)" alt="(.+?)".+?class="entry-summary">(.+?)</p>',re.DOTALL).findall(str(Regex))
						for url,icon,name,description in Regex2:
							name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;','&').replace('&#8230;','...')
							description = description.replace('&#8217;','\'').replace('&#8211;','-').replace('&#038;','&').replace('&#124;','|').replace('\\r','  ').replace('\\n',' ')
							addDir('%s' %name + ' - [COLOR fuchsia]Watch Pinoy Movies Online[/COLOR]',url,100,icon,FANART,description)
					elif 'pinoymovieshub' in searchurl:
						url = searchurl + '/?s=' + search
						OPEN = Open_Url(url)
						Regex = re.compile('class="result-item".+?href="(.+?)".+?src="(.+?)".+?alt="(.+?)".+?class="contenido"><p>(.+?)</p>',re.DOTALL).findall(OPEN)
						for url,icon,name,description in Regex:
							name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...')
							description = description.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('<strong>','').replace('</strong>','').replace('&rsquo;','\'').replace('&lsquo;','\'').replace('&ldquo;','\"').replace('&rdquo;','\"').replace('&#8230;','...')
							icon = icon.replace('-185x278','').replace('-150x150','')
							addDir('%s' %name + ' - [COLOR aqua]Pinoy Movies Hub[/COLOR]',url,35,icon,FANART,description)
					elif 'hdts' in searchurl:
						url = searchurl + '/?s=' + search
						OPEN = Open_Url(url)
						Regex = re.compile('data-movie-id.+?href="(.+?)".+?oldtitle="(.+?)".+?data-original="(.+?)".+?<p>(.+?)<!-- AddThis',re.DOTALL).findall(OPEN)
						for url1,name,icon,description in Regex:
							name = name.replace('Watch ','').replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...')
							description = description.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&').replace('&#8230;','...').replace('&#8220;','\"').replace('&#8221;','\"')
							addDir('%s' %name + ' - [COLOR lime]HDTS.ME[/COLOR]',url1,41,icon,FANART,description)
					elif 'fullpinoymovies' in searchurl:
						url = searchurl + '/?s=' + search
						OPEN = Open_Url(url)
						Regex = re.compile('class="item".+?href="(.+?)".+?src="(.+?)" alt="(.+?)".+?class="ttx"> (.+?)<div class="degradado">',re.DOTALL).findall(OPEN)
						for url,icon,name,description in Regex:
							name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#038;','&')
							description = description.replace('&#8217;','\'').replace('&#8211;','-').replace('&#038;','&').replace('&#124;','|').replace('\\n','; ')
							addDir('%s' %name + ' - [COLOR cornflowerblue]Full Pinoy Movies[/COLOR]',url,28,icon,FANART,description)						
				except:
					pass				
		setView('movies', 'mov-view')
    else: exit()
	
###################################  
 
def RESOLVE(url):
    try:
        if 'speedvid.net' in url:
            OPEN = Open_Url(url)
            link = re.compile('primary\|8777\|.+?primary\|(.+?)\|(.+?)\|.+?image\|mp4\|(.+?)\|',re.DOTALL).findall(OPEN)
            for port,server,hash in link:
                url = 'http://'+ server +'.speedvid.net:'+port+'/'+hash+'/v.mp4'
            stream_url=url
        elif 'watchpinoymoviesonline.info' in url:
            OPEN = Open_Url(url)
            url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
        elif 'pinoymovies.stream' in url:
            OPEN = Open_Url(url)
            url = re.compile('class="metaframe rptss" src="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
        elif 'linkshare.tv' in url:
            OPEN = Open_Url(url)
            url = re.compile('<source src="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = url
        elif 'freepinoytvshows' in url:
            OPEN = Open_Url(url)
            url = re.compile('source: "(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = url
        elif 'vidio.com' in url:
            stream_url = url
        elif 'nodefiles.com' in url:
            stream_url = url
        elif 'streamable.com' in url:
            stream_url = url				
        else:
			if urlresolver.HostedMediaFile(url).valid_url():
				stream_url = urlresolver.resolve(url)
			else:
				stream_url = url
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link is not available[/COLOR] ,3000)") 

def Passkey():
	kb =xbmc.Keyboard ('', 'heading', True)
	kb.setHeading('Enter Password') # optional
	kb.setHiddenInput(True) # optional
	kb.doModal()
	if (kb.isConfirmed()):
		text = kb.getText()
		if addon.get_setting('password')==text:
			return xpinoymovies_cat()
		else:
			dialog = xbmcgui.Dialog()
			ok = dialog.ok('Attention!', ' \n                          You entered a wrong password.\n                                       Please Try Again!')
			return exit()
	else: exit()
	
		
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link

    
    
def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100 or mode==24 or mode==67 or mode==77 or mode==88 or mode==101 or mode==102:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
		
def linkView():
	xbmcplugin.setContent(int(sys.argv[1]), 'files')
    
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
playlist=None
regexs=None

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass
try:
    playlist=eval(urllib.unquote_plus(params["playlist"]).replace('|',','))
except:
    pass
try:
    regexs=params["regexs"]
except:
    pass

if mode==None or url==None or len(url)<1 : MainDir()
elif mode == 2 : Movies_Cat()
elif mode == 3 : Teleserye_Cat()
elif mode == 5 : Passkey()
elif mode == 6 : MovieSearchAll()
elif mode == 10 : moviepedia_cat()
elif mode == 11 : moviepedia_content(url)
elif mode == 12 : moviepedia_links(name,url)
elif mode == 13 : moviepedia_search()
elif mode == 20 : watchpinoy_cat()
elif mode == 21 : watchpinoy_content(url)
elif mode == 22 : watchpinoy_genre(url)
elif mode == 23 : watchpinoy_live(url)
elif mode == 24 : watchpinoylive_resolve(url)
elif mode == 27 : fullpinoymovies_content(url)
elif mode == 28 : fullpinoymovies_links(name,url)
elif mode == 30 : pinoymoviestream_content(url)
elif mode == 31 : pinoymoviestream_links(name,url)
elif mode == 33 : pinoymovieshub_cat()
elif mode == 34 : pinoymovieshub_content(url)
elif mode == 35 : pinoymovieshub_links(name,url)
elif mode == 36 : pinoymovieshub_genres(url)
elif mode == 37 : pinoymovieshub_search()
elif mode == 38 : pinoymovieshubsearch_content(url)
elif mode == 39 : hdts_cat()
elif mode == 40 : hdts_content(url)
elif mode == 41 : hdts_links(name,url)
elif mode == 42 : hdts_search()
elif mode == 60 : absgma_content(url)
elif mode == 61 : absgma_links(name,url)
elif mode == 65 : lambingan_content(url)
elif mode == 66 : lambingan_links(name,url)
elif mode == 67 : lambingan_resolve(url)
elif mode == 68 : teleseryereplay_content(url)
elif mode == 69 : teleseryereplay_links(name,url)
elif mode == 75 : pinoytambayan_content(url)
elif mode == 76 : pinoytambayan_links(name,url)
elif mode == 77 : pinoytambayan_resolve(url)
elif mode == 80 : teleseryetambayan_content(url)
elif mode == 81 : teleseryetambayan_links(name,url)
elif mode == 83 : pinoytvws_content(url)
elif mode == 84 : pinoytvws_links(name,url)
elif mode == 86 : magtvnaph_content(url)
elif mode == 87 : magtvnaph_links(name,url)
elif mode == 90 : pbareplay_content(url)
elif mode == 91 : pbareplay_links(name,url)
elif mode == 96 : pinoytv_content(url)
elif mode == 97 : pinoytv_links(url)
elif mode == 98 : pinoytv_resolve(url)
elif mode == 99 : pinoyradio_content(url)
elif mode == 100: RESOLVE(url)
elif mode == 101: pbareplay_resolve(url)

elif mode == 200: pinoytvlive.getData(url,FANART)
elif mode == 201: pinoytvlive.getChannelItems(name,url,FANART)
elif mode == 202: pinoytvlive.getSubChannelItems(name,url,FANART)
elif mode == 203: pinoytvlive.play_playlist(name,playlist)
elif mode == 204: pinoytvlive.getRegexParsed(regexs,url) 
elif mode == 205:
    g_ignoreSetResolved=['plugin.video.f4mTester','plugin.video.SportsDevil']
    if not any(x in url for x in g_ignoreSetResolved):
        item = xbmcgui.ListItem(path=url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    else:
        xbmc.executebuiltin('XBMC.RunPlugin('+url+')')

xbmcplugin.endOfDirectory(int(sys.argv[1]))
