import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, xbmcaddon
import urlresolver
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.pinoyteleserye'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'pinoyteleserye'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"


BASEURL = 'http://www.pinoyhdreplay.co'
BASEURL2 = 'http://watchpinoymoviesonline.info/'
BASEURL3 = 'http://www.kapuso.be/'
BASEURL4 = 'http://www.pinoymoviepedia.ch'

def MENU():
    addDir('[B][COLOR white]KAPUSO AKO[/COLOR][/B]',BASEURL3 + 'search/label/GMA?&max-results=24',5,ART + 'kapusoako.jpg',FANART,'')
    addDir('[B][COLOR red]KAPAMILYA NATIN[/COLOR][/B]','http://pacitalaflakes.blogspot.com/search/label/ABS-CBN?m=0',5,ART + 'kapamilya.jpg',FANART,'')
    addDir('[B][COLOR green]TAMBAYAN TV[/COLOR][/B]','http://www.lambingan.su/',30,ART + 'tambayan.jpg',FANART,'')
    addDir('[B][COLOR gold]PINOY KABAYAN TV[/COLOR][/B]','url',3,ART + 'kabayan.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR magenta]PINOY OFW TV[/COLOR][/B]','url',60,ART + 'pinoyofw.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR aqua]PINOY MOVIES PORTAL [/COLOR][/B]','url',2,ART + 'pinoymov.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR orange]PBA REPLAYS[/COLOR][/B]','http://www.pbarecap.ph/videos/',70,ART +'pbalogo.jpg',ART+'basket.jpg','')
    addDir('[B][COLOR grey]MALCHUS TV LIVE[/COLOR][/B]','http://malchustv.pinoykodigroup.site/malchustv/malchustvlivetvpinoy003.xml',96,ART + 'malchustv.jpg',ART + 'fanart2.jpg','')
    setView('tvshows', 'tvshows-view')

    
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<a class='thumbx' href='(.+?)' title='(.+?)'.+?src='(.+?)'/></a>",re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&')
        icon = icon.replace('s72-c/','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile("<a class='blog-pager-older-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        if 'kapuso' in url:
            icon = ART + 'nextpagekap.jpg'
        if 'pacitalaflakes' in url:
            icon = ART + 'nextpagetamb.jpg'
        addDir('[B][COLOR red]Older Posts>>>[/COLOR][/B]',url,5,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<[iI][fF][rR][aA][mM][eE] [sS][rR][cC]="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
        except:pass
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    altlinks = re.compile('DM.player.+?"player(.+?)".+?video: "(.+?)"',re.DOTALL).findall(OPEN)
    for name2,url in altlinks:
        addDir('[B][COLOR white]Part %s[/COLOR][/B]' %name2,'http://www.dailymotion.com/embed/video/%s'%url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

###############watchpinoymovies###########

def pinoyonlinemenu():
    addDir('[B][COLOR white]Latest Movies[/COLOR][/B]',BASEURL2+'category/latest/',20,ART + 'latest.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Classic Movies[/COLOR][/B]',BASEURL2+'category/pinoy-classic-movies/',20,ART + 'classic.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Movies by Genre[/COLOR][/B]',BASEURL2,21,ART + 'genre.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]All Movies[/COLOR][/B]',BASEURL2+'category/pinoy-movies/',20,ART + 'allmov.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Live Streams[/COLOR][/B]',BASEURL2+'category/live-stream/',22,ART + 'stream.jpg',ART + 'fanart2.jpg','')
    setView('tvshows', 'tvshows-view')
    
def Mov_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('div id="content" role="main">(.+?)<!-- end #content -->',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a class="clip-link".+?href="(.+?)".+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,icon,name in Regex2:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;','&').replace('&#8230;','...')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,ART + 'fanart2.jpg','')
    np = re.compile('rel="next".+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,20,ART + 'n_p.jpg',ART + 'fanart2.jpg','')
    setView('tvshows', 'default-view')    

def live_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="item-video".+?href="(.+?)".+?<img src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon in Regex:
        if 'http' not in icon:
            icon = 'http:' + icon
        name = url.split('//')[1]
        name = name.split('/')[1].replace('-',' ').replace('live streaming','(Stream) ').title()
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,80,icon,ART + 'fanart2.jpg','')
    setView('tvshows', 'default-view')     

def cats_mov(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="sub-menu">(.+?)<!-- end #main-nav -->',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        if 'Ghost Fighter' not in name:
            if 'Slam Dunk' not in name:
                if 'Pinoy Classic' not in name:
                    if 'Latest' not in name:
                        if 'Live Stream' not in name:
                            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,20,ART + 'genre.jpg',ART + 'fanart2.jpg','')   

def res_live(url):
    OPEN = Open_Url(url)
    if '//livestream01' in OPEN:
       url = re.compile('var video="(.+?)"',re.DOTALL).findall(OPEN)[0]
    elif 'file: ' in OPEN:
        try:
            url = re.compile('file: "(.+?)"',re.DOTALL).findall(OPEN)[0]
        except:
            url = re.compile("file: '(.+?)'",re.DOTALL).findall(OPEN)[0]
    else:
        url = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)[0]
        url = url.replace('?autoplay=1&wmode=opaque&rel=0&showinfo=0&modestbranding=0','')
    url1 = urlresolver.resolve(url)
    if url1:
        try:
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title':description})
            liz.setProperty("IsPlayable","true")
            liz.setPath(url1)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        except: pass
    else:
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
        
        
############.pinoymoviepedia.to###########
def moviechannel():
    addDir('[B][COLOR white]Pinoy Movies[/COLOR][/B]',BASEURL4+'/category/tagalog-movies/',90,ART + 'pediamovs.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Hollywood Movies[/COLOR][/B]',BASEURL4+'/category/hollywood-movies/',90,ART + 'pedia_holly.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Hollywood Bluray[/COLOR][/B]',BASEURL4+'/category/bluray/',90,ART + 'pedia_blu.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Asian Movies[/COLOR][/B]',BASEURL4+'/category/asian-movies/',90,ART + 'pedia_asian.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Pinoy Teleserye Latest[/COLOR][/B]',BASEURL4+'/category/pinoy-teleserye/',90,ART + 'pedia_late.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Pinoy Teleserye Shows[/COLOR][/B]',BASEURL4,91,ART + 'pedia_shows.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Search Moviepedia[/COLOR][/B]','url',93,ART + 'search_pedia.jpg',FANART,'')
    setView('tvshows', 'tvshows-view')
    
def pinoypedia_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<li class="border-radius.+?src="(.+?)".+?href="(.+?)" title="(.+?)">',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        icon = icon.replace('-210x142','').replace('-199x142','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,95,icon,ART + 'fanart2.jpg','')
    np = re.compile('rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page >>>[/COLOR][/B]',url,90,ART + 'pedia_np.jpg',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(50)')    

def pinoypedia_TV(url):
    OPEN = Open_Url(url)
    Regex = re.compile('tag menu-item.+?href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&#038;','&')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,90,ART + 'pedia_shows.jpg',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(50)') 
    
def pinoypedia_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('data-lazy-src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        url = url.replace('https://href.li/?','')
        if urlresolver.HostedMediaFile(url).valid_url():
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,ART + 'fanart2.jpg',name)
    altlinks = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in altlinks:
        if 'dailymotion' in altlinks:
            url = 'http:' + url
        if urlresolver.HostedMediaFile(url).valid_url():    
            try:
                name2 = url.split('//')[1].replace('www.','')
                name2 = name2.split('/')[0].split('.')[0].title()
            except:pass
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,ART + 'fanart2.jpg',name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def pedia_Search():
    keyb = xbmc.Keyboard('', 'Search')
    keyb.doModal()
    if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ','+')
            url = BASEURL4 + '/?s=' + search
            pinoypedia_content(url)
    
############### lambingan.########### 
def lamb_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="post-thumbnail".+?img src="(.+?)".+?href="(.+?)" title="(.+?)"',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
        if 'http' not in icon:
            icon = 'http:' + icon
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,35,icon,FANART,'')
    np = re.compile('class="current".+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,30,ART + 'lampnp.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')     
    
def lamb_vids(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<iframe frameborder="0".+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        if 'http:' not in url:
            url = 'http:' + url
        if '/dm-' in url:
            name2 = 'Main Link [COLOR blue](Dailymotion)[/COLOR]'
        elif '/mo-'in url:
            name2 = 'Main Link [COLOR cyan](Openload)[/COLOR]'
        elif '/all-'in url:
            name2 = 'Main Link [COLOR yellow](Estream)[/COLOR]'
        else:
            name2= 'Short Clip'
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,40,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)') 

def lamb_res(url):
    if 'watchnew.asia' in url:
        OPEN = Open_Url(url)
        try:
            url = re.compile('<[iI][fF][rR][aA][mM][eE].+?[sS][rR][cC]="(.+?)"',re.DOTALL).findall(OPEN)[0]
            if 'http:' not in url:
                url = 'http:' + url
                stream_url = urlresolver.resolve(url)
            else:
                stream_url = urlresolver.resolve(url)
        except:
            url = re.compile('<div class=.+?container.+?href="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
    elif 'libangan' in url:
        Holder = Open_Url(url)
        if 'www.dailymotion.com' in Holder:
            url = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(Holder)[0]
            url = 'http:' + url
        else:
            url = re.compile('<div class=.+?container.+?href="(.+?)"',re.DOTALL).findall(Holder)[0]
        stream_url = urlresolver.resolve(url)
    else:
        stream_url = urlresolver.resolve(url)
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={"Title": description})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)



    
######################## pinoyhdreplay###############  
def PHD_menu():
    addDir('[B][COLOR white]All TELESERYE[/COLOR][/B]',BASEURL+'/pinoy_teleserye/?page1',65,ART + 'reply.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]ABS-CBN TELESERYE[/COLOR][/B]',BASEURL+'/board/movies/1-1',65,ART + 'reply.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]ABS-CBN NEWS[/COLOR][/B]',BASEURL+'/board/abs_cbn_news/9-1',65,ART + 'reply.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]GMA TELESERYE[/COLOR][/B]',BASEURL+'/board/gma_teleserye/6-1',65,ART + 'reply.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]All TAGALOG Movie[/COLOR][/B]',BASEURL+'/pinoy_movie/new_movies/1-1',65,ART + 'reply.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]CLASSIC Movie[/COLOR][/B]',BASEURL+'/pinoy_movie/new_movies/classic_tagalog/29-1',65,ART + 'reply.jpg',ART + 'fanart2.jpg','')
    setView('tvshows', 'tvshows-view')    

def PHD_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('id="entryID.+?src="(.+?)".+?href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for icon,url,name in Regex:
        name=name.replace('&#39;',"'")
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,BASEURL+url,68,icon,ART + 'fanart2.jpg','')
    np = re.compile('class="pagesBlockuz(.+?)</div>',re.DOTALL).findall(OPEN)[0]
    np2 = re.compile('"swchItem.+?href="(.+?)"',re.DOTALL).findall(str(np))
    for url in np2:
        if '/pinoy_teleserye/movies/' in url:
            name = url.replace('/pinoy_teleserye/movies/1-','').title()
        elif '/abs_cbn_news/' in url:
            name = url.replace('/pinoy_teleserye/abs_cbn_news/9-','').title()
        elif '/gma_teleserye/' in url:
            name = url.replace('/pinoy_teleserye/gma_teleserye/6-','').title()
        elif '/pinoy_movie/new_movies/classic_tagalog/' in url:
            name = url.replace('/pinoy_movie/new_movies/classic_tagalog/29-','').title()
        elif '/pinoy_movie/new_movies/' in url:
            name = url.replace('/pinoy_movie/new_movies/1-','').title()
        elif '/pinoy_teleserye/' in url:
            name = url.replace('/pinoy_teleserye/?page','').replace('/pinoy_teleserye/','1').title()
        else:
            name=url
        addDir('[B][COLOR red]Page %s[/COLOR][/B]' %name,BASEURL+url,65,ART + 'rep_np.jpg',ART + 'fanart2.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(50)')   
 

    

def PHD_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<option value="(.+?)">(.+?)<',re.DOTALL).findall(OPEN)
    for url,name2 in Regex:
        name2 = name2.title()
        if urlresolver.HostedMediaFile(url):
               addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,ART + 'fanart2.jpg',name)
    try:
        altRegex = re.compile('<table align="center"(.+?)</table>',re.DOTALL).findall(OPEN)
        altRegex2 = re.compile('href="(.+?)"',re.DOTALL).findall(str(altRegex))  
        for url in altRegex2:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
            if urlresolver.HostedMediaFile(url).valid_url():
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,ART + 'fanart2.jpg',name)
    except:pass

    try:
        altRegex3 = re.compile('style="text-align: right;"><a href="(.+?)"',re.DOTALL).findall(OPEN)
        for url in altRegex3:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
            if urlresolver.HostedMediaFile(url).valid_url():
                addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,ART + 'fanart2.jpg',name)
    except:pass      
###############################
###  PBA RECAP ##########
def PBA_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('left">Videos</h1>(.+?)</ul>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)".+?src="(.+?)".+?<h.+?>(.+?)</h2>',re.DOTALL).findall(str(Regex)) 
    for url,icon,name in Regex2:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,101,icon,ART + 'basket.jpg','')
    np = re.compile('rel="next" href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page >>>[/COLOR][/B]',url,70,ART + 'pba_np.jpg',ART + 'basket.jpg','')
    xbmc.executebuiltin('Container.SetViewMode(50)') 

def PBA_RESOLVE(url):
    hosts = []
    stream_url = []
    host = ''
    try:
        Page = Open_Url(url)
        #print 'page>> '+Page
        holder = re.compile('href="http://ballersph.weebly.com/(.+?)"',re.DOTALL).findall(Page)[0]
        holder = 'http://ballersph.weebly.com/'+holder
        #print 'GW::::::::::::'+holder
        OPEN = Open_Url(holder) 
        match = re.compile('class="tabbed-box-content (.+?)".+?iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)
        for label,link in match:
                label = label.replace('tab-0','1st Quarter').replace('tab-1','2nd Quarter').replace('tab-2','3rd Quarter').replace('tab-3','4th Quarter')
                host = '[B][COLOR white]%s[/COLOR][/B]' %label
                hosts.append(host)
                stream_url.append(link)
        if len(match) >1:
                dialog = xbmcgui.Dialog()
                ret = dialog.select('Please Select Quarter',hosts)
                if ret == -1:
                    return
                elif ret > -1:
                        url = stream_url[ret]
        else:
            url = re.compile('iframe.+?src="(.+?)"').findall(OPEN)[0]
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR cornflowerblue]No Links Available[/COLOR] ,5000)")
    url = 'http:' + url  
    try:    
        stream_url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass

########################IPTV
def maliptv(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<title>(.+?)</title>.+?<thumbnail>(.+?)</thumbnail>.+?.+?<stream_url>(.+?)</stream_url>',re.DOTALL).findall(OPEN)
    for name,icon,url in Regex:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,102,icon,FANART,'')

def resolve_IPTV(url):
    print 'MALIPTV '+url
    try:
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)   
    except:pass        
###################################   
def RESOLVE(url):
    #print '>>>>>>>>>>>>>>>>>>>>>>' + url + '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
    try:
        if 'speedvid.net' in url:
            OPEN = Open_Url(url)
            link = re.compile('primary\|8777\|.+?primary\|(.+?)\|(.+?)\|.+?image\|mp4\|(.+?)\|',re.DOTALL).findall(OPEN)
            for port,server,hash in link:
                url = 'http://'+ server +'.speedvid.net:'+port+'/'+hash+'/v.mp4'
            stream_url=url
        elif 'watchpinoymoviesonline.info' in url:
            OPEN = Open_Url(url)
            url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
        else:
            stream_url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)") 

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link

    
    
def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100 or mode==80 or mode==50 or mode==40 or mode==101 or mode==102:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
    
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None




try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass

if mode==None or url==None or len(url)<1 : MENU()
elif mode == 2 : pinoyonlinemenu()
elif mode == 3 : moviechannel()
elif mode == 5 : Get_content(url) 
elif mode == 10 : Get_links(name,url)
elif mode == 20 : Mov_Menu(url)
elif mode == 21 : cats_mov(url)
elif mode == 22 : live_Menu(url)
elif mode == 30 : lamb_content(url)
elif mode == 35 : lamb_vids(name,url)
elif mode == 40 : lamb_res(url)
elif mode == 50 : RES_mov(url) 

elif mode == 60 : PHD_menu()
elif mode == 61 : PHD_ts(url)
elif mode == 62 : PHD_wdys(url)
elif mode == 63 : PHD_wends(url)
elif mode == 65 : PHD_content(url)
elif mode == 68 : PHD_links(name,url)
elif mode == 70 : PBA_content(url)
elif mode == 80 : res_live(url)
elif mode == 90 : pinoypedia_content(url)
elif mode == 91 : pinoypedia_TV(url)
elif mode == 93 : pedia_Search()
elif mode == 95 : pinoypedia_links(name,url)
elif mode == 96 : maliptv(url)
elif mode ==100: RESOLVE(url)
elif mode ==101: PBA_RESOLVE(url)
elif mode ==102: resolve_IPTV(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))

















