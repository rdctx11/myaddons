import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys,base64,shutil,time

addon_id            = 'plugin.video.NIELDC-IPTV'
addon 				= xbmcaddon.Addon(addon_id)
AddonTitle          = 'NIELDC IPTV'
fanart              = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon                = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
dialog              = xbmcgui.Dialog()
dp                  = xbmcgui.DialogProgress()
F4M                 = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.f4mTester'))

M3U_Replacer        = base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1Z1UjZVQWh4')
M3U_Cleaner         = base64.decodestring('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1E0V3hnU1Q3')


if addon.getSetting('m3ureplacer1') == "true":
	autoiptvmode = 3
else:
	autoiptvmode = 4
	
if addon.getSetting('m3ureplacer2') == "true":
	customiptvmode = 5
else:
	customiptvmode = 6
	
def Get_Menu():
    addDir('[COLOR lime][B]AUTO IPTV[/B][/COLOR]','url',11,icon,fanart)
    addDir('[COLOR yellow][B]CUSTOM PLAYLISTS[/B][/COLOR]','url',12,icon,fanart)
    # addDir('[COLOR magenta][B]ALTERNATE STREAMS[/B][/COLOR]','aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0JRMTVnRGgz',2,icon,fanart)
	
    Set_View()
	
def AutoIPTV_Servers(url):    
    addDir('[COLOR lime][B]USA TV [AUTOIPTV][/B][/COLOR]','http://playlist.autoiptv.net/normal.php?c=US',autoiptvmode,icon,fanart)
    addDir('[COLOR lime][B]UK TV[/B][/COLOR]','http://playlist.autoiptv.net/normal.php?c=UK',autoiptvmode,icon,fanart)
    addDir('[COLOR lime][B]ARABIC TV[/B][/COLOR]','http://playlist.autoiptv.net/normal.php?c=SA',autoiptvmode,icon,fanart)
    addDir('[COLOR lime][B]SPORTS[/B][/COLOR]','http://playlist.autoiptv.net/sport.php',autoiptvmode,icon,fanart)
    addDir('[COLOR lime][B]MOVIES[/B][/COLOR]','http://playlist.autoiptv.net/movie.php',autoiptvmode,icon,fanart)
    addDir('[COLOR lime][B]SERIES[/B][/COLOR]','http://playlist.autoiptv.net/series.php',autoiptvmode,icon,fanart)
    addDir('[COLOR lime][B]24/7 TV SHOWS[/B][/COLOR]','http://playlist.autoiptv.net/247.php',autoiptvmode,icon,fanart)
    addDir('[COLOR lime][B]KIDS[/B][/COLOR]','http://playlist.autoiptv.net/kids.php',autoiptvmode,icon,fanart)
    addDir('[COLOR lime][B]MUSIC[/B][/COLOR]','http://playlist.autoiptv.net/music.php',autoiptvmode,icon,fanart)
    addDir('[COLOR lime][B]NEWS[/B][/COLOR]','http://playlist.autoiptv.net/news.php',autoiptvmode,icon,fanart)
    addDir('[COLOR lime][B]RELIGION[/B][/COLOR]','http://playlist.autoiptv.net/faith.php',autoiptvmode,icon,fanart)
	
    Set_View()
	
def CustomIPTV_Servers(url):
    if addon.getSetting('custom_m3u1') == 'true':
		addDir('[COLOR yellow][B]%s[/B][/COLOR]' %str(addon.getSetting('m3u1_name')),str(addon.getSetting('m3u1_url')),customiptvmode,icon,fanart)
    if addon.getSetting('custom_m3u2') == 'true':
		addDir('[COLOR yellow][B]%s[/B][/COLOR]' %str(addon.getSetting('m3u2_name')),str(addon.getSetting('m3u2_url')),customiptvmode,icon,fanart)
    if addon.getSetting('custom_m3u3') == 'true':
		addDir('[COLOR yellow][B]%s[/B][/COLOR]' %str(addon.getSetting('m3u3_name')),str(addon.getSetting('m3u3_url')),customiptvmode,icon,fanart)
    if addon.getSetting('custom_m3u4') == 'true':
		addDir('[COLOR yellow][B]%s[/B][/COLOR]' %str(addon.getSetting('m3u4_name')),str(addon.getSetting('m3u4_url')),customiptvmode,icon,fanart)
    if addon.getSetting('custom_m3u5') == 'true':
		addDir('[COLOR yellow][B]%s[/B][/COLOR]' %str(addon.getSetting('m3u5_name')),str(addon.getSetting('m3u5_url')),customiptvmode,icon,fanart)
    if addon.getSetting('custom_m3u6') == 'true':
		addDir('[COLOR yellow][B]%s[/B][/COLOR]' %str(addon.getSetting('m3u6_name')),str(addon.getSetting('m3u6_url')),customiptvmode,icon,fanart)
    if addon.getSetting('custom_m3u7') == 'true':
		addDir('[COLOR yellow][B]%s[/B][/COLOR]' %str(addon.getSetting('m3u7_name')),str(addon.getSetting('m3u7_url')),customiptvmode,icon,fanart)
    if addon.getSetting('custom_m3u8') == 'true':
		addDir('[COLOR yellow][B]%s[/B][/COLOR]' %str(addon.getSetting('m3u8_name')),str(addon.getSetting('m3u8_url')),customiptvmode,icon,fanart)
    if addon.getSetting('custom_m3u9') == 'true':
		addDir('[COLOR yellow][B]%s[/B][/COLOR]' %str(addon.getSetting('m3u9_name')),str(addon.getSetting('m3u9_url')),customiptvmode,icon,fanart)
    if addon.getSetting('custom_m3u10') == 'true':
		addDir('[COLOR yellow][B]%s[/B][/COLOR]' %str(addon.getSetting('m3u10_name')),str(addon.getSetting('m3u10_url')),customiptvmode,icon,fanart)
		
    Set_View()
	

def Main_Menu_Open(url):

    if not os.path.exists(F4M):
        dialog = xbmcgui.Dialog()
        dialog.ok('[COLOR red]F4M TESTER NOT INSTALLED![/COLOR]', "This addon requires F4M Tester be installed. Please install F4M from the Shani Repo at http://fusion.tvaddons.ag")
        quit()

    req = urllib2.Request(base64.b64decode(url))
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    link=link.replace('\n','').replace('\r','').replace('<fanart></fanart>','<fanart>x</fanart>').replace('<thumbnail></thumbnail>','<thumbnail>x</thumbnail>').replace('<utube>','<link>https://www.youtube.com/watch?v=').replace('</utube>','</link>')#.replace('></','>x</')
    the_lists = re.compile('<item>(.+?)</item>').findall(link)

    for item in the_lists:
 
        name=re.compile('<name>(.+?)</name>').findall(item)[0]
        url=re.compile('<link>(.+?)</link>').findall(item)[0]
        addDir(name,url,3,icon,fanart)

    Set_View()

def AutoIPTV_Links(url):

	link3 = open_url(M3U_Cleaner)
	link3=link3.replace('\n','').replace('\r','').replace('<fanart></fanart>','<fanart>x</fanart>').replace('<thumbnail></thumbnail>','<thumbnail>x</thumbnail>').replace('<utube>','<link>https://www.youtube.com/watch?v=').replace('</utube>','</link>')
	string= re.compile('<item>(.+?)</item>').findall(link3)
	
	link2 = open_url(M3U_Replacer)
	link2=link2.replace('\n','').replace('\r','').replace('<fanart></fanart>','<fanart>x</fanart>').replace('<thumbnail></thumbnail>','<thumbnail>x</thumbnail>').replace('<utube>','<link>https://www.youtube.com/watch?v=').replace('</utube>','</link>')#.replace('></','>x</')
	match= re.compile('<item>(.+?)</item>').findall(link2)

	response = open_url(url)
	response = response.replace('#AAASTREAM:','#A:')
	response = response.replace('#EXTINF:','#A:')
	matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
	li = []
	for params, display_name, url in matches:
		item_data = {"params": params, "display_name": display_name, "url": url}
		li.append(item_data)
	m3u_list = []
	for channel in li:
		item_data = {"display_name": channel["display_name"], "url": channel["url"]}
		matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
		for field, value in matches:
			item_data[field.strip().lower().replace('-', '_')] = value.strip()
		m3u_list.append(item_data)
			
	for channel in m3u_list:
		name = GetEncodeString(channel["display_name"])
		url = GetEncodeString(channel["url"])
		if addon.getSetting('m3u8mode1') == "true":
			url = url.replace('\\n','').replace('\n','').replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8').replace('plugin://plugin.video.f4mTester','').replace('/?','').replace('streamtype=TSDOWNLOADER','').replace('streamtype=HLSRETRY','').replace('url=','').replace('&','').replace('amp;','').replace('name=','').replace('FTFA','').replace('F.T.F.A','').replace('F.T.F.A.','').replace('TV','').replace(';','').replace('Maverick','').replace('IPTV','').replace('.ts','.m3u8')
		else:
			url = url.replace('\\n','').replace('\n','').replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8').replace('plugin://plugin.video.f4mTester','').replace('/?','').replace('streamtype=TSDOWNLOADER','').replace('streamtype=HLSRETRY','').replace('url=','').replace('&','').replace('amp;','').replace('name=','').replace('FTFA','').replace('F.T.F.A','').replace('F.T.F.A.','').replace('TV','').replace(';','').replace('Maverick','').replace('IPTV','')

		for item in match:
			old=re.compile('<old>(.+?)</old>').findall(item)[0]
			new=re.compile('<new>(.+?)</new>').findall(item)[0]
			if new.lower() == "null": new = ""
			name = name.replace(old,new)
		for items in string:
			old=re.compile('<old>(.+?)</old>').findall(items)[0]
			new=re.compile('<new>(.+?)</new>').findall(items)[0]
			name = name.replace(old,new)
			name = name.lstrip(' ')

		addLink(name,url,10,icon,fanart)

		Set_View()

def AutoIPTV_Links_2(url):

    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        response=link
        response = response.replace('#AAASTREAM:','#A:')
        response = response.replace('#EXTINF:','#A:')
        matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
        li = []
        for params, display_name, url in matches:
            item_data = {"params": params, "display_name": display_name, "url": url}
            li.append(item_data)
        list = []
        for channel in li:
            item_data = {"display_name": channel["display_name"], "url": channel["url"]}
            matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
            for field, value in matches:
                item_data[field.strip().lower().replace('-', '_')] = value.strip()
            list.append(item_data)
        for channel in list:
            name = GetEncodeString(channel["display_name"])
            url = GetEncodeString(channel["url"])
            if addon.getSetting('m3u8mode1') == "true":
				url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8').replace('.ts','.m3u8')
            else:
				url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
				
            addLink(name,url,10,icon,fanart)
    except:
        dialog.ok(AddonTitle,'Sorry, there was an error getting the information from the server. Please try again later.')
        quit()

    Set_View()

def CustomIPTV_Links(url):

	link3 = open_url(M3U_Cleaner)
	link3=link3.replace('\n','').replace('\r','').replace('<fanart></fanart>','<fanart>x</fanart>').replace('<thumbnail></thumbnail>','<thumbnail>x</thumbnail>').replace('<utube>','<link>https://www.youtube.com/watch?v=').replace('</utube>','</link>')
	string= re.compile('<item>(.+?)</item>').findall(link3)
	
	link2 = open_url(M3U_Replacer)
	link2=link2.replace('\n','').replace('\r','').replace('<fanart></fanart>','<fanart>x</fanart>').replace('<thumbnail></thumbnail>','<thumbnail>x</thumbnail>').replace('<utube>','<link>https://www.youtube.com/watch?v=').replace('</utube>','</link>')#.replace('></','>x</')
	match= re.compile('<item>(.+?)</item>').findall(link2)

	response = open_url(url)
	response = response.replace('#AAASTREAM:','#A:')
	response = response.replace('#EXTINF:','#A:')
	matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
	li = []
	for params, display_name, url in matches:
		item_data = {"params": params, "display_name": display_name, "url": url}
		li.append(item_data)
	m3u_list = []
	for channel in li:
		item_data = {"display_name": channel["display_name"], "url": channel["url"]}
		matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
		for field, value in matches:
			item_data[field.strip().lower().replace('-', '_')] = value.strip()
		m3u_list.append(item_data)
			
	for channel in m3u_list:
		name = GetEncodeString(channel["display_name"])
		url = GetEncodeString(channel["url"])
		if addon.getSetting('m3u8mode2') == "true":
			url = url.replace('\\n','').replace('\n','').replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8').replace('plugin://plugin.video.f4mTester','').replace('/?','').replace('streamtype=TSDOWNLOADER','').replace('streamtype=HLSRETRY','').replace('url=','').replace('&','').replace('amp;','').replace('name=','').replace('FTFA','').replace('F.T.F.A','').replace('F.T.F.A.','').replace('TV','').replace(';','').replace('Maverick','').replace('IPTV','').replace('.ts','.m3u8')
		else:
			url = url.replace('\\n','').replace('\n','').replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8').replace('plugin://plugin.video.f4mTester','').replace('/?','').replace('streamtype=TSDOWNLOADER','').replace('streamtype=HLSRETRY','').replace('url=','').replace('&','').replace('amp;','').replace('name=','').replace('FTFA','').replace('F.T.F.A','').replace('F.T.F.A.','').replace('TV','').replace(';','').replace('Maverick','').replace('IPTV','')

		for item in match:
			old=re.compile('<old>(.+?)</old>').findall(item)[0]
			new=re.compile('<new>(.+?)</new>').findall(item)[0]
			if new.lower() == "null": new = ""
			name = name.replace(old,new)
		for items in string:
			old=re.compile('<old>(.+?)</old>').findall(items)[0]
			new=re.compile('<new>(.+?)</new>').findall(items)[0]
			name = name.replace(old,new)
			name = name.lstrip(' ')

		addLink(name,url,10,icon,fanart)

		Set_View()

def CustomIPTV_Links_2(url):

    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        response=link
        response = response.replace('#AAASTREAM:','#A:')
        response = response.replace('#EXTINF:','#A:')
        matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
        li = []
        for params, display_name, url in matches:
            item_data = {"params": params, "display_name": display_name, "url": url}
            li.append(item_data)
        list = []
        for channel in li:
            item_data = {"display_name": channel["display_name"], "url": channel["url"]}
            matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
            for field, value in matches:
                item_data[field.strip().lower().replace('-', '_')] = value.strip()
            list.append(item_data)
        for channel in list:
            name = GetEncodeString(channel["display_name"])
            url = GetEncodeString(channel["url"])
            if addon.getSetting('m3u8mode2') == "true":
				url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8').replace('.ts','.m3u8')
            else:
				url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
				
            addLink(name,url,10,icon,fanart)
    except:
        dialog.ok(AddonTitle,'Sorry, there was an error getting the information from the server. Please try again later.')
        quit()

    Set_View()


def Set_View():

    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])
    if version >= 11.0 and version <= 11.9:
        codename = 'Eden'
    elif version >= 12.0 and version <= 12.9:
        codename = 'Frodo'
    elif version >= 13.0 and version <= 13.9:
        codename = 'Gotham'
    elif version >= 14.0 and version <= 14.9:
        codename = 'Helix'
    elif version >= 15.0 and version <= 15.9:
        codename = 'Isengard'
    elif version >= 16.0 and version <= 16.9:
        codename = 'Jarvis'
    elif version >= 17.0 and version <= 17.9:
        codename = 'Krypton'
    else: codename = "Decline"
    
    if codename == "Jarvis":
        xbmc.executebuiltin('Container.SetViewMode(50)')
    elif codename == "Krypton":
        xbmc.executebuiltin('Container.SetViewMode(55)')
    else: xbmc.executebuiltin('Container.SetViewMode(50)')

def Player(name,url,iconimage):

    try:
        name,url = url.split('|SPLIT|')
    except: pass
    if not 'f4m'in url:
        if '.m3u8'in url:
            url = 'plugin://plugin.video.f4mTester/?url='+url+'&amp;streamtype=HLSRETRY&amp;name='+name+'&amp;iconImage='+iconimage
        elif '.ts'in url:
            url = 'plugin://plugin.video.f4mTester/?url='+url+'&amp;streamtype=TSDOWNLOADER&amp;name='+name+'&amp;iconImage='+iconimage 

    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    xbmc.Player().play(url,liz,False)

def GetEncodeString(str):
    try:
        import chardet
        str = str.decode(chardet.detect(str)["encoding"]).encode("utf-8")
    except:
        try:
            str = str.encode("utf-8")
        except:
            pass
    return str

def open_url(url):

    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
    req.add_header('Referer', 'https://www.google.com/')
    response = urllib2.urlopen(req, timeout = 30)
    link=response.read()
    response.close()
    return link

def _get_keyboard( default="", heading="", hidden=False ):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard( default, heading, hidden )
    keyboard.doModal()
    if ( keyboard.isConfirmed() ):
        return unicode( keyboard.getText(), "utf-8" )
    return default

def addDir(name,url,mode,iconimage,fanartimage):

    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanartimage="+urllib.quote_plus(fanartimage)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setProperty( "fanart_Image", fanartimage )
    liz.setProperty( "icon_Image", iconimage )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addLink(name,url,mode,iconimage,fanartimage):

    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+iconimage+"&fanartimage="+urllib.quote_plus(fanartimage)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setProperty( "fanart_Image", fanartimage )
    liz.setProperty( "icon_Image", iconimage )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                               
        return param

params=get_params(); name=None; url=None; mode=None; iconimage=None; fanartimage=None
try: name=urllib.unquote_plus(params["name"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: fanartimage=urllib.quote_plus(params["fanartimage"])
except: pass
 
if mode==None or url==None or len(url)<1: Get_Menu()
elif mode==1:Get_Menu()
elif mode==2:Main_Menu_Open(url)
elif mode==3:AutoIPTV_Links(url)
elif mode==4:AutoIPTV_Links_2(url)
elif mode==5:CustomIPTV_Links(url)
elif mode==6:CustomIPTV_Links_2(url)
elif mode==10:Player(name,url,iconimage)
elif mode==11:AutoIPTV_Servers(url)
elif mode==12:CustomIPTV_Servers(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))