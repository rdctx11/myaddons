from xbmcaddon import Addon
import main

ADDON = Addon("plugin.video.stream.searcher")
	
if ADDON.getSetting('startup.clear') == 'true':
	main.clear_cache()
