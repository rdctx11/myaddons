from xbmcswift2 import Plugin
from xbmcaddon import Addon
import xbmcvfs

ADDON = Addon("plugin.video.stream.searcher")
plugin = Plugin()
	
if ADDON.getSetting('startup.clear') == 'true':
    last_read = plugin.get_storage('last_read')
    last_read.clear()
    xbmcvfs.delete('special://profile/addon_data/plugin.video.stream.searcher/cache.json')
